/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     _FINAL_ = 258,
     _AUTOMATON_ = 259,
     _SAFE_ = 260,
     _NEXT_ = 261,
     _ANALYSE_ = 262,
     _PLACE_ = 263,
     _MARKING_ = 264,
     _TRANSITION_ = 265,
     _CONSUME_ = 266,
     _PRODUCE_ = 267,
     _comma_ = 268,
     _colon_ = 269,
     _semicolon_ = 270,
     IDENTIFIER = 271,
     NUMBER = 272,
     _equals_ = 273,
     _AND_ = 274,
     _OR_ = 275,
     _EXPATH_ = 276,
     _ALLPATH_ = 277,
     _ALWAYS_ = 278,
     _EVENTUALLY_ = 279,
     _UNTIL_ = 280,
     _NOT_ = 281,
     _greaterorequal_ = 282,
     _greaterthan_ = 283,
     _lessorequal_ = 284,
     _lessthan_ = 285,
     _notequal_ = 286,
     _FORMULA_ = 287,
     _leftparenthesis_ = 288,
     _rightparenthesis_ = 289,
     _STATE_ = 290,
     _PATH_ = 291,
     _GENERATOR_ = 292,
     _RECORD_ = 293,
     _END_ = 294,
     _SORT_ = 295,
     _FUNCTION_ = 296,
     _DO_ = 297,
     _ARRAY_ = 298,
     _ENUMERATE_ = 299,
     _CONSTANT_ = 300,
     _BOOLEAN_ = 301,
     _OF_ = 302,
     _BEGIN_ = 303,
     _WHILE_ = 304,
     _IF_ = 305,
     _THEN_ = 306,
     _ELSE_ = 307,
     _SWITCH_ = 308,
     _CASE_ = 309,
     _REPEAT_ = 310,
     _FOR_ = 311,
     _TO_ = 312,
     _ALL_ = 313,
     _EXIT_ = 314,
     _RETURN_ = 315,
     _TRUE_ = 316,
     _FALSE_ = 317,
     _MOD_ = 318,
     _VAR_ = 319,
     _GUARD_ = 320,
     _iff_ = 321,
     _implies_ = 322,
     _leftbracket_ = 323,
     _rightbracket_ = 324,
     _dot_ = 325,
     _plus_ = 326,
     _minus_ = 327,
     _times_ = 328,
     _divide_ = 329,
     _slash_ = 330,
     _EXISTS_ = 331,
     _STRONG_ = 332,
     _WEAK_ = 333,
     _FAIR_ = 334
   };
#endif
/* Tokens.  */
#define _FINAL_ 258
#define _AUTOMATON_ 259
#define _SAFE_ 260
#define _NEXT_ 261
#define _ANALYSE_ 262
#define _PLACE_ 263
#define _MARKING_ 264
#define _TRANSITION_ 265
#define _CONSUME_ 266
#define _PRODUCE_ 267
#define _comma_ 268
#define _colon_ 269
#define _semicolon_ 270
#define IDENTIFIER 271
#define NUMBER 272
#define _equals_ 273
#define _AND_ 274
#define _OR_ 275
#define _EXPATH_ 276
#define _ALLPATH_ 277
#define _ALWAYS_ 278
#define _EVENTUALLY_ 279
#define _UNTIL_ 280
#define _NOT_ 281
#define _greaterorequal_ 282
#define _greaterthan_ 283
#define _lessorequal_ 284
#define _lessthan_ 285
#define _notequal_ 286
#define _FORMULA_ 287
#define _leftparenthesis_ 288
#define _rightparenthesis_ 289
#define _STATE_ 290
#define _PATH_ 291
#define _GENERATOR_ 292
#define _RECORD_ 293
#define _END_ 294
#define _SORT_ 295
#define _FUNCTION_ 296
#define _DO_ 297
#define _ARRAY_ 298
#define _ENUMERATE_ 299
#define _CONSTANT_ 300
#define _BOOLEAN_ 301
#define _OF_ 302
#define _BEGIN_ 303
#define _WHILE_ 304
#define _IF_ 305
#define _THEN_ 306
#define _ELSE_ 307
#define _SWITCH_ 308
#define _CASE_ 309
#define _REPEAT_ 310
#define _FOR_ 311
#define _TO_ 312
#define _ALL_ 313
#define _EXIT_ 314
#define _RETURN_ 315
#define _TRUE_ 316
#define _FALSE_ 317
#define _MOD_ 318
#define _VAR_ 319
#define _GUARD_ 320
#define _iff_ 321
#define _implies_ 322
#define _leftbracket_ 323
#define _rightbracket_ 324
#define _dot_ 325
#define _plus_ 326
#define _minus_ 327
#define _times_ 328
#define _divide_ 329
#define _slash_ 330
#define _EXISTS_ 331
#define _STRONG_ 332
#define _WEAK_ 333
#define _FAIR_ 334




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 84 "readnet-syntax.yy"
{
    char* str;
    int value;
    UType* t;
    URcList* rcl;
    UEnList* el;
    ULVal* lval;
    int* exl;
    UStatement* stm;
    case_list* cl;
    UFunction* fu;
    UExpression* ex;
    arc_list* al;
    formula* form;
    IdList* idl;
    UTermList* tlist;
    Place* pl;
    Transition* tr;
    fmode* fm;
    TrSymbol* ts;
    VaSymbol* varsy;
}
/* Line 1529 of yacc.c.  */
#line 230 "readnet-syntax.hh"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

