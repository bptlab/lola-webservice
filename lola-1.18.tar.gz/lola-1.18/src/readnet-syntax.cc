/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     _FINAL_ = 258,
     _AUTOMATON_ = 259,
     _SAFE_ = 260,
     _NEXT_ = 261,
     _ANALYSE_ = 262,
     _PLACE_ = 263,
     _MARKING_ = 264,
     _TRANSITION_ = 265,
     _CONSUME_ = 266,
     _PRODUCE_ = 267,
     _comma_ = 268,
     _colon_ = 269,
     _semicolon_ = 270,
     IDENTIFIER = 271,
     NUMBER = 272,
     _equals_ = 273,
     _AND_ = 274,
     _OR_ = 275,
     _EXPATH_ = 276,
     _ALLPATH_ = 277,
     _ALWAYS_ = 278,
     _EVENTUALLY_ = 279,
     _UNTIL_ = 280,
     _NOT_ = 281,
     _greaterorequal_ = 282,
     _greaterthan_ = 283,
     _lessorequal_ = 284,
     _lessthan_ = 285,
     _notequal_ = 286,
     _FORMULA_ = 287,
     _leftparenthesis_ = 288,
     _rightparenthesis_ = 289,
     _STATE_ = 290,
     _PATH_ = 291,
     _GENERATOR_ = 292,
     _RECORD_ = 293,
     _END_ = 294,
     _SORT_ = 295,
     _FUNCTION_ = 296,
     _DO_ = 297,
     _ARRAY_ = 298,
     _ENUMERATE_ = 299,
     _CONSTANT_ = 300,
     _BOOLEAN_ = 301,
     _OF_ = 302,
     _BEGIN_ = 303,
     _WHILE_ = 304,
     _IF_ = 305,
     _THEN_ = 306,
     _ELSE_ = 307,
     _SWITCH_ = 308,
     _CASE_ = 309,
     _REPEAT_ = 310,
     _FOR_ = 311,
     _TO_ = 312,
     _ALL_ = 313,
     _EXIT_ = 314,
     _RETURN_ = 315,
     _TRUE_ = 316,
     _FALSE_ = 317,
     _MOD_ = 318,
     _VAR_ = 319,
     _GUARD_ = 320,
     _iff_ = 321,
     _implies_ = 322,
     _leftbracket_ = 323,
     _rightbracket_ = 324,
     _dot_ = 325,
     _plus_ = 326,
     _minus_ = 327,
     _times_ = 328,
     _divide_ = 329,
     _slash_ = 330,
     _EXISTS_ = 331,
     _STRONG_ = 332,
     _WEAK_ = 333,
     _FAIR_ = 334
   };
#endif
/* Tokens.  */
#define _FINAL_ 258
#define _AUTOMATON_ 259
#define _SAFE_ 260
#define _NEXT_ 261
#define _ANALYSE_ 262
#define _PLACE_ 263
#define _MARKING_ 264
#define _TRANSITION_ 265
#define _CONSUME_ 266
#define _PRODUCE_ 267
#define _comma_ 268
#define _colon_ 269
#define _semicolon_ 270
#define IDENTIFIER 271
#define NUMBER 272
#define _equals_ 273
#define _AND_ 274
#define _OR_ 275
#define _EXPATH_ 276
#define _ALLPATH_ 277
#define _ALWAYS_ 278
#define _EVENTUALLY_ 279
#define _UNTIL_ 280
#define _NOT_ 281
#define _greaterorequal_ 282
#define _greaterthan_ 283
#define _lessorequal_ 284
#define _lessthan_ 285
#define _notequal_ 286
#define _FORMULA_ 287
#define _leftparenthesis_ 288
#define _rightparenthesis_ 289
#define _STATE_ 290
#define _PATH_ 291
#define _GENERATOR_ 292
#define _RECORD_ 293
#define _END_ 294
#define _SORT_ 295
#define _FUNCTION_ 296
#define _DO_ 297
#define _ARRAY_ 298
#define _ENUMERATE_ 299
#define _CONSTANT_ 300
#define _BOOLEAN_ 301
#define _OF_ 302
#define _BEGIN_ 303
#define _WHILE_ 304
#define _IF_ 305
#define _THEN_ 306
#define _ELSE_ 307
#define _SWITCH_ 308
#define _CASE_ 309
#define _REPEAT_ 310
#define _FOR_ 311
#define _TO_ 312
#define _ALL_ 313
#define _EXIT_ 314
#define _RETURN_ 315
#define _TRUE_ 316
#define _FALSE_ 317
#define _MOD_ 318
#define _VAR_ 319
#define _GUARD_ 320
#define _iff_ 321
#define _implies_ 322
#define _leftbracket_ 323
#define _rightbracket_ 324
#define _dot_ 325
#define _plus_ 326
#define _minus_ 327
#define _times_ 328
#define _divide_ 329
#define _slash_ 330
#define _EXISTS_ 331
#define _STRONG_ 332
#define _WEAK_ 333
#define _FAIR_ 334




/* Copy the first part of user declarations.  */
#line 22 "readnet-syntax.yy"

#include "dimensions.h"
#include "net.h"
#include "graph.h"
#include "symboltab.h"
#include "formula.h"
#include "buchi.h"
#include "unfold.h"
#include "verbose.h"
#include <cstdio>
#include <climits>
#include <unistd.h>
#include <cstdarg>
#include "Globals.h"
#include <libgen.h>


extern UBooType* TheBooType;
extern UNumType* TheNumType;
extern char* yytext;

extern Transition* LastAttractor;  ///< Last transition in list of

#define YYDEBUG 1
void yyerror(char const*);
void yyerrors(char* token, char const* format, ...);

class arc_list {
    public:
        PlSymbol* place;
        UTermList* mt;
        unsigned int nu;
        arc_list* next;
        arc_list() : place(NULL), mt(NULL), nu(0), next(NULL) {}
        arc_list(PlSymbol* _place, UTermList* _mt, unsigned int _nu, arc_list* _next) : place(_place), mt(_mt), nu(_nu), next(_next) {}
};

class case_list {
    public:
        UStatement* stm;
        UExpression* exp;
        case_list* next;
        case_list() : stm(NULL), exp(NULL), next(NULL) {}
        case_list(UStatement* _stm, UExpression* _exp, case_list* _next) : stm(_stm), exp(_exp), next(_next) {}
};

/* list of places and multiplicities to become arcs */

int CurrentCapacity;
UFunction* CurrentFunction;
Place* P;
Transition* T;
Symbol* S;
PlSymbol* PS;
TrSymbol* TS;
SymbolTab* GlobalTable;
SymbolTab* LocalTable;
UVar* V;
VaSymbol* VS;



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 1
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 84 "readnet-syntax.yy"
{
    char* str;
    int value;
    UType* t;
    URcList* rcl;
    UEnList* el;
    ULVal* lval;
    int* exl;
    UStatement* stm;
    case_list* cl;
    UFunction* fu;
    UExpression* ex;
    arc_list* al;
    formula* form;
    IdList* idl;
    UTermList* tlist;
    Place* pl;
    Transition* tr;
    fmode* fm;
    TrSymbol* ts;
    VaSymbol* varsy;
}
/* Line 193 of yacc.c.  */
#line 339 "readnet-syntax.cc"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */
#line 194 "readnet-syntax.yy"

extern YYSTYPE yylval;
extern int yylex();
extern FILE *yyin;
extern int yylineno;
extern int yycolno;


/* Line 216 of yacc.c.  */
#line 359 "readnet-syntax.cc"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   458

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  80
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  93
/* YYNRULES -- Number of rules.  */
#define YYNRULES  216
/* YYNRULES -- Number of states.  */
#define YYNSTATES  443

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   334

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,    11,    17,    23,    29,    34,    36,
      38,    43,    46,    50,    56,    58,    62,    63,    66,    69,
      70,    74,    76,    79,    84,    86,    88,    92,    97,   103,
     107,   109,   112,   114,   116,   119,   124,   128,   129,   132,
     133,   136,   141,   143,   147,   154,   155,   157,   161,   165,
     169,   171,   175,   177,   179,   181,   183,   185,   187,   189,
     191,   193,   199,   205,   215,   222,   228,   236,   239,   241,
     246,   253,   254,   257,   262,   266,   268,   273,   277,   281,
     285,   287,   291,   295,   297,   300,   302,   306,   310,   314,
     318,   322,   326,   328,   332,   336,   338,   342,   346,   350,
     352,   355,   357,   359,   363,   368,   372,   374,   376,   378,
     380,   382,   387,   388,   390,   394,   398,   400,   404,   406,
     410,   414,   418,   419,   428,   431,   436,   437,   440,   444,
     448,   450,   452,   456,   458,   460,   461,   463,   467,   471,
     475,   477,   481,   483,   487,   489,   494,   495,   497,   501,
     503,   506,   507,   519,   521,   525,   529,   531,   533,   534,
     537,   538,   540,   544,   548,   552,   554,   558,   562,   566,
     570,   574,   578,   582,   586,   590,   593,   597,   602,   607,
     611,   619,   627,   632,   637,   642,   647,   652,   657,   659,
     665,   669,   670,   672,   677,   682,   686,   690,   693,   697,
     699,   705,   707,   709,   713,   717,   718,   723,   727,   731,
     733,   737,   741,   743,   744,   747,   748
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      81,     0,    -1,    87,   134,    -1,    87,   134,    82,   156,
      -1,    87,   134,     7,     8,    86,    -1,    87,   134,     7,
      10,    83,    -1,    87,   134,     7,     9,   132,    -1,    87,
     134,     4,   164,    -1,    32,    -1,   140,    -1,    84,    68,
      85,    69,    -1,   140,    70,    -1,   140,    18,   120,    -1,
      85,    75,   140,    18,   120,    -1,   140,    -1,   140,    70,
     120,    -1,    -1,    87,    88,    -1,    40,    90,    -1,    -1,
      41,    89,    97,    -1,    91,    -1,    90,    91,    -1,    16,
      18,    92,    15,    -1,    46,    -1,    16,    -1,    38,    95,
      39,    -1,    43,    92,    47,    92,    -1,    68,    17,    13,
      17,    69,    -1,    44,    93,    39,    -1,    94,    -1,    94,
      93,    -1,    16,    -1,    96,    -1,    95,    96,    -1,    16,
      14,    92,    15,    -1,   102,    98,   105,    -1,    -1,    64,
      99,    -1,    -1,    99,   100,    -1,   101,    14,    92,    15,
      -1,    16,    -1,    16,    13,   101,    -1,    16,    33,   103,
      34,    14,    92,    -1,    -1,   104,    -1,   103,    15,   104,
      -1,   101,    14,    92,    -1,    48,   106,    39,    -1,   107,
      -1,   106,    15,   107,    -1,   108,    -1,   109,    -1,   110,
      -1,   111,    -1,   112,    -1,   115,    -1,   118,    -1,   113,
      -1,   114,    -1,    49,   120,    42,   106,    39,    -1,    55,
     106,    25,   120,    39,    -1,    56,    16,    18,   120,    57,
     120,    42,   106,    39,    -1,    56,    58,    16,    42,   106,
      39,    -1,    50,   120,    51,   106,    39,    -1,    50,   120,
      51,   106,    52,   106,    39,    -1,    60,   120,    -1,    59,
      -1,    53,   120,   116,    39,    -1,    53,   120,   116,    52,
     106,    39,    -1,    -1,   117,   116,    -1,    54,   120,    14,
     106,    -1,   119,    18,   120,    -1,    16,    -1,   119,    68,
     120,    69,    -1,   119,    70,    16,    -1,   120,    66,   121,
      -1,   120,    67,   121,    -1,   121,    -1,   121,    19,   122,
      -1,   121,    20,   122,    -1,   122,    -1,    26,   122,    -1,
     123,    -1,   123,    18,   124,    -1,   123,    28,   124,    -1,
     123,    30,   124,    -1,   123,    27,   124,    -1,   123,    29,
     124,    -1,   123,    31,   124,    -1,   124,    -1,   124,    71,
     125,    -1,   124,    72,   125,    -1,   125,    -1,   125,    73,
     126,    -1,   125,    74,   126,    -1,   125,    63,   126,    -1,
     126,    -1,    72,   127,    -1,   127,    -1,    16,    -1,   119,
      70,    16,    -1,   119,    68,   120,    69,    -1,    33,   120,
      34,    -1,    61,    -1,    62,    -1,   128,    -1,   130,    -1,
      17,    -1,    16,    33,   129,    34,    -1,    -1,   120,    -1,
     120,    13,   129,    -1,    68,   131,    69,    -1,   120,    -1,
     120,    75,   131,    -1,   133,    -1,   132,    13,   133,    -1,
     140,    14,    17,    -1,   140,    14,   143,    -1,    -1,     8,
     136,    15,     9,   135,   141,    15,   147,    -1,   137,   138,
      -1,   136,    15,   137,   138,    -1,    -1,     5,    14,    -1,
       5,    17,    14,    -1,   138,    13,   139,    -1,   139,    -1,
     140,    -1,   140,    14,    92,    -1,    16,    -1,    17,    -1,
      -1,   142,    -1,   141,    13,   142,    -1,   140,    14,    17,
      -1,   140,    14,   143,    -1,   144,    -1,   143,    71,   144,
      -1,   145,    -1,   145,    14,    17,    -1,    16,    -1,    16,
      33,   146,    34,    -1,    -1,   145,    -1,   145,    13,   146,
      -1,   148,    -1,   147,   148,    -1,    -1,    10,   151,   149,
     150,   152,    11,   153,    15,    12,   153,    15,    -1,    98,
      -1,    78,    79,    98,    -1,    77,    79,    98,    -1,    16,
      -1,    17,    -1,    -1,    65,   120,    -1,    -1,   154,    -1,
     154,    13,   153,    -1,   140,    14,    17,    -1,   140,    14,
     143,    -1,    17,    -1,    33,   120,    34,    -1,   157,    18,
     155,    -1,   157,    31,   155,    -1,   157,    29,   155,    -1,
     157,    27,   155,    -1,   157,    30,   155,    -1,   157,    28,
     155,    -1,   156,    19,   156,    -1,   156,    20,   156,    -1,
      26,   156,    -1,    68,   120,    69,    -1,    76,   158,    14,
     156,    -1,    58,   158,    14,   156,    -1,    33,   156,    34,
      -1,    21,   159,    68,   156,    25,   156,    69,    -1,    22,
     159,    68,   156,    25,   156,    69,    -1,    21,   159,    23,
     156,    -1,    22,   159,    23,   156,    -1,    21,   159,     6,
     156,    -1,    22,   159,     6,   156,    -1,    21,   159,    24,
     156,    -1,    22,   159,    24,   156,    -1,   140,    -1,   140,
      70,    33,   120,    34,    -1,   140,    14,    92,    -1,    -1,
     160,    -1,    76,   158,    14,   160,    -1,    58,   158,    14,
     160,    -1,   160,    19,   160,    -1,   160,    20,   160,    -1,
      26,   160,    -1,    33,   160,    34,    -1,   161,    -1,   161,
      70,    68,   162,    69,    -1,   140,    -1,   163,    -1,   162,
      75,   163,    -1,   140,    18,   120,    -1,    -1,   165,   166,
     168,   170,    -1,    35,   167,    15,    -1,   167,    13,    16,
      -1,    16,    -1,     3,   169,    15,    -1,   169,    13,    16,
      -1,    16,    -1,    -1,   170,   171,    -1,    -1,    10,    16,
      57,    16,    65,   172,   156,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   205,   205,   206,   207,   221,   230,   231,   236,   241,
     251,   305,   320,   330,   349,   359,   391,   393,   398,   399,
     399,   404,   405,   410,   423,   424,   435,   438,   445,   454,
     461,   462,   470,   482,   483,   491,   503,   510,   512,   516,
     518,   523,   538,   541,   548,   575,   577,   578,   582,   598,
     603,   604,   614,   615,   616,   617,   618,   619,   620,   621,
     622,   627,   640,   653,   676,   690,   700,   714,   727,   735,
     755,   779,   780,   785,   792,   805,   814,   827,   847,   857,
     867,   872,   882,   892,   897,   906,   911,   918,   925,   932,
     939,   946,   953,   958,   968,   978,   983,   993,  1003,  1013,
    1018,  1027,  1032,  1060,  1080,  1097,  1098,  1102,  1106,  1107,
    1108,  1117,  1147,  1148,  1151,  1158,  1183,  1186,  1193,  1194,
    1199,  1212,  1247,  1247,  1365,  1366,  1371,  1372,  1373,  1378,
    1379,  1384,  1392,  1423,  1424,  1428,  1430,  1431,  1436,  1449,
    1487,  1488,  1493,  1494,  1502,  1519,  1557,  1558,  1559,  1564,
    1565,  1570,  1570,  1799,  1800,  1801,  1806,  1807,  1812,  1813,
    1823,  1824,  1825,  1830,  1840,  1859,  1863,  1873,  1878,  1883,
    1888,  1893,  1898,  1903,  1906,  1909,  1912,  1918,  1922,  1926,
    1929,  1932,  1935,  1938,  1941,  1944,  1947,  1950,  1957,  1967,
    1984,  1996,  1997,  2002,  2006,  2010,  2013,  2016,  2019,  2020,
    2030,  2044,  2055,  2056,  2061,  2075,  2075,  2122,  2132,  2145,
    2162,  2167,  2174,  2184,  2186,  2191,  2191
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "_FINAL_", "_AUTOMATON_", "_SAFE_",
  "_NEXT_", "_ANALYSE_", "_PLACE_", "_MARKING_", "_TRANSITION_",
  "_CONSUME_", "_PRODUCE_", "_comma_", "_colon_", "_semicolon_",
  "IDENTIFIER", "NUMBER", "_equals_", "_AND_", "_OR_", "_EXPATH_",
  "_ALLPATH_", "_ALWAYS_", "_EVENTUALLY_", "_UNTIL_", "_NOT_",
  "_greaterorequal_", "_greaterthan_", "_lessorequal_", "_lessthan_",
  "_notequal_", "_FORMULA_", "_leftparenthesis_", "_rightparenthesis_",
  "_STATE_", "_PATH_", "_GENERATOR_", "_RECORD_", "_END_", "_SORT_",
  "_FUNCTION_", "_DO_", "_ARRAY_", "_ENUMERATE_", "_CONSTANT_",
  "_BOOLEAN_", "_OF_", "_BEGIN_", "_WHILE_", "_IF_", "_THEN_", "_ELSE_",
  "_SWITCH_", "_CASE_", "_REPEAT_", "_FOR_", "_TO_", "_ALL_", "_EXIT_",
  "_RETURN_", "_TRUE_", "_FALSE_", "_MOD_", "_VAR_", "_GUARD_", "_iff_",
  "_implies_", "_leftbracket_", "_rightbracket_", "_dot_", "_plus_",
  "_minus_", "_times_", "_divide_", "_slash_", "_EXISTS_", "_STRONG_",
  "_WEAK_", "_FAIR_", "$accept", "input", "formulaheader", "atransition",
  "hlprefix", "firingmode", "aplace", "declarations", "declaration", "@1",
  "sortdeclarations", "sortdeclaration", "sortdescription", "enums", "enu",
  "recordcomponents", "recordcomponent", "functiondeclaration",
  "vardeclarations", "vdeclarations", "vdeclaration", "identlist", "head",
  "fparlists", "fparlist", "body", "statement_seq", "statement",
  "while_statement", "repeat_statement", "for_statement",
  "forall_statement", "if_statement", "return_statement", "exit_statement",
  "case_statement", "caselist", "case", "assignment", "lvalue",
  "expression", "express", "expre", "expr", "exp", "term", "factor", "fac",
  "functioncall", "expressionlist", "arrayvalue", "valuelist",
  "amarkinglist", "amarking", "net", "@2", "placelists", "capacity",
  "placelist", "place", "nodeident", "markinglist", "marking", "multiterm",
  "mtcomponent", "hlterm", "termlist", "transitionlist", "transition",
  "@3", "transitionvariables", "tname", "guard", "arclist", "arc", "numex",
  "ctlformula", "cplace", "quantification", "transformula",
  "transitionformula", "formulatransition", "parfiringmode", "fmodeblock",
  "automaton", "@4", "statepart", "statelist", "finalpart", "finallist",
  "transitionpart", "btransition", "@5", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    80,    81,    81,    81,    81,    81,    81,    82,    83,
      83,    84,    85,    85,    86,    86,    87,    87,    88,    89,
      88,    90,    90,    91,    92,    92,    92,    92,    92,    92,
      93,    93,    94,    95,    95,    96,    97,    98,    98,    99,
      99,   100,   101,   101,   102,   103,   103,   103,   104,   105,
     106,   106,   107,   107,   107,   107,   107,   107,   107,   107,
     107,   108,   109,   110,   111,   112,   112,   113,   114,   115,
     115,   116,   116,   117,   118,   119,   119,   119,   120,   120,
     120,   121,   121,   121,   122,   122,   123,   123,   123,   123,
     123,   123,   123,   124,   124,   124,   125,   125,   125,   125,
     126,   126,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   128,   129,   129,   129,   130,   131,   131,   132,   132,
     133,   133,   135,   134,   136,   136,   137,   137,   137,   138,
     138,   139,   139,   140,   140,   141,   141,   141,   142,   142,
     143,   143,   144,   144,   145,   145,   146,   146,   146,   147,
     147,   149,   148,   150,   150,   150,   151,   151,   152,   152,
     153,   153,   153,   154,   154,   155,   155,   156,   156,   156,
     156,   156,   156,   156,   156,   156,   156,   156,   156,   156,
     156,   156,   156,   156,   156,   156,   156,   156,   157,   157,
     158,   159,   159,   160,   160,   160,   160,   160,   160,   160,
     160,   161,   162,   162,   163,   165,   164,   166,   167,   167,
     168,   169,   169,   170,   170,   172,   171
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     4,     5,     5,     5,     4,     1,     1,
       4,     2,     3,     5,     1,     3,     0,     2,     2,     0,
       3,     1,     2,     4,     1,     1,     3,     4,     5,     3,
       1,     2,     1,     1,     2,     4,     3,     0,     2,     0,
       2,     4,     1,     3,     6,     0,     1,     3,     3,     3,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     5,     5,     9,     6,     5,     7,     2,     1,     4,
       6,     0,     2,     4,     3,     1,     4,     3,     3,     3,
       1,     3,     3,     1,     2,     1,     3,     3,     3,     3,
       3,     3,     1,     3,     3,     1,     3,     3,     3,     1,
       2,     1,     1,     3,     4,     3,     1,     1,     1,     1,
       1,     4,     0,     1,     3,     3,     1,     3,     1,     3,
       3,     3,     0,     8,     2,     4,     0,     2,     3,     3,
       1,     1,     3,     1,     1,     0,     1,     3,     3,     3,
       1,     3,     1,     3,     1,     4,     0,     1,     3,     1,
       2,     0,    11,     1,     3,     3,     1,     1,     0,     2,
       0,     1,     3,     3,     3,     1,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     2,     3,     4,     4,     3,
       7,     7,     4,     4,     4,     4,     4,     4,     1,     5,
       3,     0,     1,     4,     4,     3,     3,     2,     3,     1,
       5,     1,     1,     3,     3,     0,     4,     3,     3,     1,
       3,     3,     1,     0,     2,     0,     7
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
      16,     0,     0,     1,   126,     0,    19,    17,     2,     0,
       0,     0,     0,    18,    21,     0,   205,     0,     8,     0,
     127,     0,   126,   133,   134,   124,   130,   131,     0,    22,
       0,    20,    37,     7,     0,     0,     0,     0,   191,   191,
       0,     0,     0,     0,     0,   188,     3,     0,   128,   122,
       0,     0,     0,    25,     0,     0,     0,    24,     0,     0,
      45,    39,     0,     0,     0,     4,    14,     6,   118,     0,
       5,     0,     9,     0,     0,     0,     0,   201,     0,   192,
     199,     0,   175,     0,     0,     0,   102,   110,     0,     0,
     106,   107,     0,     0,     0,     0,    80,    83,    85,    92,
      95,    99,   101,   108,   109,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   135,   125,   129,   132,     0,
       0,    33,     0,    32,     0,    30,     0,    23,    42,     0,
       0,    46,    38,     0,    36,   209,     0,     0,   213,     0,
       0,     0,     0,    11,   197,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   179,
       0,     0,   112,    84,     0,   116,     0,   100,     0,     0,
       0,     0,   176,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   173,   174,
     165,     0,   167,   170,   172,   169,   171,   168,     0,     0,
     136,     0,    26,    34,     0,    29,    31,     0,     0,     0,
       0,     0,    40,     0,    75,     0,     0,     0,     0,     0,
      68,     0,     0,    50,    52,    53,    54,    55,    56,    59,
      60,    57,    58,     0,     0,   207,   212,     0,   206,    15,
     119,   144,   120,   121,   140,   142,     0,     0,   198,     0,
       0,   184,   182,   186,     0,   195,   196,     0,   185,   183,
     187,     0,   190,   178,   113,     0,   105,     0,   115,     0,
     103,    78,    79,    81,    82,    86,    89,    87,    90,    88,
      91,    93,    94,    98,    96,    97,   177,     0,     0,     0,
       0,     0,     0,    27,     0,    43,    48,    47,     0,     0,
       0,     0,    71,     0,     0,     0,    67,     0,    49,     0,
       0,     0,   208,     0,   210,     0,   214,   146,     0,     0,
      10,     0,     0,   194,   193,     0,     0,     0,   202,     0,
     112,   111,   117,   104,   189,   166,   138,   139,   137,     0,
     123,   149,    35,    28,    44,     0,     0,     0,     0,     0,
      71,     0,     0,     0,    51,    74,     0,    77,   211,     0,
     147,     0,   141,   143,     0,    12,     0,     0,   200,     0,
       0,   114,   156,   157,   151,   150,    41,     0,     0,     0,
      69,     0,    72,     0,     0,     0,    76,     0,   146,   145,
       0,   180,   204,   203,   181,    37,    61,    65,     0,     0,
       0,    62,     0,     0,     0,   148,    13,     0,     0,   153,
     158,     0,    73,    70,     0,    64,   215,    37,    37,     0,
       0,    66,     0,     0,   155,   154,   159,   160,     0,   216,
       0,     0,   161,    63,     0,     0,   160,   163,   164,   160,
     162,     0,   152
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    19,    70,    71,   246,    65,     2,     7,    15,
      13,    14,    59,   124,   125,   120,   121,    31,    62,   132,
     212,   129,    32,   130,   131,   134,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   349,   350,   232,    94,
     165,    96,    97,    98,    99,   100,   101,   102,   103,   265,
     104,   166,    67,    68,     8,   115,    10,    11,    25,    26,
      45,   199,   200,   243,   244,   245,   361,   340,   341,   395,
     410,   374,   420,   431,   432,   192,    46,    47,    85,    78,
      79,    80,   327,   328,    33,    34,    64,   136,   138,   237,
     238,   316,   423
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -304
static const yytype_int16 yypact[] =
{
    -304,    46,    35,  -304,    75,   107,  -304,  -304,    16,   268,
     120,   318,   125,   107,  -304,   147,  -304,   285,  -304,   104,
    -304,   208,   275,  -304,  -304,   239,  -304,   302,   108,  -304,
     322,  -304,   288,  -304,   327,   318,   318,   318,    25,    25,
     104,   104,   318,    28,   318,   287,   305,   214,  -304,  -304,
     318,   318,   108,  -304,   345,   108,   347,  -304,   348,   349,
     350,  -304,   321,   351,   367,  -304,   301,   359,  -304,   360,
    -304,   307,   303,    25,    25,   318,   318,  -304,    11,   317,
     306,    13,   305,   141,   363,   364,   -18,  -304,    28,    28,
    -304,  -304,    28,   132,   145,   242,   319,  -304,   229,   269,
     199,  -304,  -304,  -304,  -304,   365,   353,   104,   104,   153,
     153,   153,   153,   153,   153,   318,   239,  -304,  -304,   366,
      56,  -304,   335,  -304,   342,   347,   370,  -304,   374,   375,
      93,  -304,   350,   142,  -304,  -304,   252,   372,  -304,    28,
     318,   326,   318,  -304,   317,   206,   376,   377,   104,   104,
     104,   104,    25,    25,   324,   104,   104,   104,   104,  -304,
     108,   104,    28,  -304,    73,   152,   325,  -304,    28,   379,
      28,    28,  -304,    28,    28,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,   104,    28,  -304,  -304,
    -304,    28,  -304,  -304,  -304,  -304,  -304,  -304,   382,   276,
    -304,   108,  -304,  -304,   108,  -304,  -304,   380,   350,   108,
     350,   384,  -304,   385,  -304,    28,    28,    28,   142,    -5,
    -304,    28,    59,  -304,  -304,  -304,  -304,  -304,  -304,  -304,
    -304,  -304,  -304,    29,   386,  -304,  -304,   308,   383,   278,
    -304,   368,  -304,   329,  -304,   389,     9,   387,  -304,    25,
      25,   305,   305,   305,   149,  -304,  -304,   318,   305,   305,
     305,   258,  -304,  -304,    36,   373,  -304,    28,  -304,   246,
     261,   319,   319,  -304,  -304,   269,   269,   269,   269,   269,
     269,   199,   199,  -304,  -304,  -304,  -304,   139,   144,   330,
     318,   394,   391,  -304,   339,  -304,  -304,  -304,   108,   108,
     154,   163,   182,   249,   392,   393,   278,   142,  -304,    28,
      28,   395,  -304,   396,  -304,   397,  -304,   398,   398,   400,
    -304,   318,    28,  -304,  -304,   104,   401,   212,  -304,   104,
      28,  -304,  -304,   262,  -304,  -304,  -304,   329,  -304,   332,
     394,  -304,  -304,  -304,  -304,   403,   142,   142,    28,   198,
     361,    28,    28,   378,  -304,   278,   253,  -304,  -304,   369,
     408,   388,  -304,  -304,   405,   278,    37,    28,  -304,   318,
      67,  -304,  -304,  -304,  -304,  -304,  -304,    99,   151,     4,
    -304,   142,  -304,    -7,   204,   142,  -304,   411,   398,  -304,
      28,  -304,   278,  -304,  -304,   -48,  -304,  -304,   142,   142,
     140,  -304,    28,   189,   371,  -304,   278,   352,   354,  -304,
     381,   192,   409,  -304,   157,  -304,  -304,   288,   288,    28,
     418,  -304,   142,   104,  -304,  -304,   278,   318,   194,   305,
     416,   417,   421,  -304,   334,   423,   318,  -304,   329,   318,
    -304,   422,  -304
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -304,  -304,  -304,  -304,  -304,  -304,  -304,  -304,  -304,  -304,
    -304,   425,   -45,   314,  -304,  -304,   320,  -304,  -183,  -304,
    -304,  -126,  -304,  -304,   231,  -304,  -214,   135,  -304,  -304,
    -304,  -304,  -304,  -304,  -304,  -304,    94,  -304,  -304,  -130,
     -34,   183,   -80,  -304,   122,   178,   143,   355,  -304,   113,
    -304,   180,  -304,   309,  -304,  -304,  -304,   428,   402,   404,
     -11,  -304,   155,  -284,   133,  -303,    65,  -304,   114,  -304,
    -304,  -304,  -304,  -173,  -304,   193,   -39,  -304,    69,   419,
     -61,  -304,  -304,    87,  -304,  -304,  -304,  -304,  -304,  -304,
    -304,  -304,  -304
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -78
static const yytype_int16 yytable[] =
{
      27,    82,    83,   233,   303,   337,   213,   118,   163,    95,
     122,   304,   144,   145,   360,   162,    61,   148,   399,   155,
      16,    86,    87,    17,    66,    69,    72,    77,    77,   407,
     408,    84,   401,    84,   149,   150,   156,   157,    89,    27,
      27,    23,    24,     4,    86,    87,     3,   309,    18,   330,
     -75,    73,   -75,   305,    88,   164,   107,   108,    74,   170,
     171,    89,    77,    77,    84,    84,    90,    91,   188,   189,
     170,   171,   119,    92,   307,     5,     6,    93,   320,   151,
       9,   158,   295,    75,   321,   360,   107,   108,   233,    90,
      91,   255,   256,   273,   274,   202,    92,   310,   308,   311,
      93,    76,   170,   171,   198,   239,   391,   266,   210,   251,
     252,   253,   254,   105,   307,   262,   258,   259,   260,   261,
      23,    24,   263,    12,    53,    38,    39,   211,   264,    69,
      40,   247,   377,   378,   269,    22,   394,    41,   396,   170,
     171,    77,    77,    28,   146,   147,    54,   286,    86,    87,
     438,    55,    56,   287,    57,   307,   292,   288,   214,   293,
     107,   108,    42,    30,   296,    89,   307,   400,   107,   108,
     190,   403,    43,   334,   325,   159,    58,   233,   335,   413,
      44,   300,   301,   302,   411,   412,   191,   306,   323,   324,
     397,   215,   216,    90,    91,   217,   346,   218,   219,   422,
      92,   220,   221,   398,   307,   170,   171,   307,   428,   307,
     170,   171,   409,   168,   347,   169,   233,   233,   170,   171,
     170,   171,    48,   170,   171,   152,   153,   267,   415,   170,
     171,   421,   109,   433,   424,   425,   348,   380,    77,    77,
     248,   110,   111,   112,   113,   114,   326,   175,   170,   171,
     381,   233,    51,   344,   345,   233,   176,   177,   178,   179,
     180,   402,   183,   440,   307,   234,   441,   235,   233,   233,
     170,   171,   184,   185,   351,   355,   356,   107,   108,   198,
       9,   368,    20,   329,    49,    21,   366,   369,   365,   290,
     370,   291,   233,    35,    36,    37,   264,   275,   276,   277,
     278,   279,   280,   193,   194,   195,   196,   197,   170,   171,
     364,   172,   170,   171,   379,   333,    52,   383,   384,   170,
     171,   313,   386,   314,   107,   108,   283,   284,   285,   -77,
     -76,   -77,   -76,   392,    23,    24,   152,   153,   173,   174,
     181,   182,   241,   242,   170,   171,   241,   336,   372,   373,
     241,   437,    61,   271,   272,    60,   406,   106,   326,   281,
     282,   119,    63,   123,   127,   126,   128,   135,   414,   133,
     137,   139,   140,   143,   141,   142,   154,   160,   161,   186,
     201,   205,   204,   207,   429,   426,   187,   208,   236,   209,
     249,   250,   257,   315,   268,   270,   289,   294,   298,   299,
     318,   317,   312,   319,   339,   322,   342,   331,   343,   353,
     352,   357,   358,   359,   241,   348,   430,   363,   376,   367,
     385,   388,   389,   390,   307,   430,   387,   404,   430,   427,
     434,   417,   435,   418,   436,   439,   416,   442,    29,   206,
     203,   297,   354,   371,   382,   338,   419,   332,   167,   240,
      50,   362,   116,   405,   375,   117,   393,     0,    81
};

static const yytype_int16 yycheck[] =
{
      11,    40,    41,   133,   218,   289,   132,    52,    88,    43,
      55,    16,    73,    74,   317,    33,    64,     6,    14,     6,
       4,    16,    17,     7,    35,    36,    37,    38,    39,    77,
      78,    42,    39,    44,    23,    24,    23,    24,    33,    50,
      51,    16,    17,     8,    16,    17,     0,    18,    32,    13,
      68,    26,    70,    58,    26,    89,    19,    20,    33,    66,
      67,    33,    73,    74,    75,    76,    61,    62,   107,   108,
      66,    67,    16,    68,    15,    40,    41,    72,    69,    68,
       5,    68,   208,    58,    75,   388,    19,    20,   218,    61,
      62,   152,   153,   173,   174,    39,    68,    68,    39,    70,
      72,    76,    66,    67,   115,   139,    69,    34,    15,   148,
     149,   150,   151,    44,    15,   160,   155,   156,   157,   158,
      16,    17,   161,    16,    16,    21,    22,    34,   162,   140,
      26,   142,   346,   347,   168,    15,    69,    33,    39,    66,
      67,   152,   153,    18,    75,    76,    38,   186,    16,    17,
     434,    43,    44,   187,    46,    15,   201,   191,    16,   204,
      19,    20,    58,    16,   209,    33,    15,   381,    19,    20,
      17,   385,    68,    34,    25,    34,    68,   307,    34,    39,
      76,   215,   216,   217,   398,   399,    33,   221,   249,   250,
      39,    49,    50,    61,    62,    53,    42,    55,    56,    42,
      68,    59,    60,    52,    15,    66,    67,    15,   422,    15,
      66,    67,   395,    68,    51,    70,   346,   347,    66,    67,
      66,    67,    14,    66,    67,    19,    20,    75,    39,    66,
      67,    39,    18,    39,   417,   418,    54,    39,   249,   250,
      34,    27,    28,    29,    30,    31,   257,    18,    66,    67,
      52,   381,    13,   298,   299,   385,    27,    28,    29,    30,
      31,    57,    63,   436,    15,    13,   439,    15,   398,   399,
      66,    67,    73,    74,    25,   309,   310,    19,    20,   290,
       5,    69,    14,    25,     9,    17,   325,    75,   322,    13,
     329,    15,   422,     8,     9,    10,   330,   175,   176,   177,
     178,   179,   180,   110,   111,   112,   113,   114,    66,    67,
     321,    69,    66,    67,   348,    69,    14,   351,   352,    66,
      67,    13,    69,    15,    19,    20,   183,   184,   185,    68,
      68,    70,    70,   367,    16,    17,    19,    20,    19,    20,
      71,    72,    16,    17,    66,    67,    16,    17,    16,    17,
      16,    17,    64,   170,   171,    33,   390,    70,   369,   181,
     182,    16,    35,    16,    15,    17,    16,    16,   402,    48,
       3,    70,    13,    70,    14,    68,    70,    14,    14,    14,
      14,    39,    47,    13,   423,   419,    33,    13,    16,    14,
      14,    14,    68,    10,    69,    16,    14,    17,    14,    14,
      71,    33,    16,    14,    10,    18,    15,    34,    69,    16,
      18,    16,    16,    16,    16,    54,   427,    17,    15,    18,
      42,    13,    34,    18,    15,   436,    57,    16,   439,    11,
      14,    79,    15,    79,    13,    12,    65,    15,    13,   125,
     120,   210,   307,   330,   350,   290,    65,   267,    93,   140,
      22,   318,    50,   388,   340,    51,   369,    -1,    39
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    81,    87,     0,     8,    40,    41,    88,   134,     5,
     136,   137,    16,    90,    91,    89,     4,     7,    32,    82,
      14,    17,    15,    16,    17,   138,   139,   140,    18,    91,
      16,    97,   102,   164,   165,     8,     9,    10,    21,    22,
      26,    33,    58,    68,    76,   140,   156,   157,    14,     9,
     137,    13,    14,    16,    38,    43,    44,    46,    68,    92,
      33,    64,    98,    35,   166,    86,   140,   132,   133,   140,
      83,    84,   140,    26,    33,    58,    76,   140,   159,   160,
     161,   159,   156,   156,   140,   158,    16,    17,    26,    33,
      61,    62,    68,    72,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   130,   158,    70,    19,    20,    18,
      27,    28,    29,    30,    31,   135,   138,   139,    92,    16,
      95,    96,    92,    16,    93,    94,    17,    15,    16,   101,
     103,   104,    99,    48,   105,    16,   167,     3,   168,    70,
      13,    14,    68,    70,   160,   160,   158,   158,     6,    23,
      24,    68,    19,    20,    70,     6,    23,    24,    68,    34,
      14,    14,    33,   122,   120,   120,   131,   127,    68,    70,
      66,    67,    69,    19,    20,    18,    27,    28,    29,    30,
      31,    71,    72,    63,    73,    74,    14,    33,   156,   156,
      17,    33,   155,   155,   155,   155,   155,   155,   140,   141,
     142,    14,    39,    96,    47,    39,    93,    13,    13,    14,
      15,    34,   100,   101,    16,    49,    50,    53,    55,    56,
      59,    60,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   118,   119,    13,    15,    16,   169,   170,   120,
     133,    16,    17,   143,   144,   145,    85,   140,    34,    14,
      14,   156,   156,   156,   156,   160,   160,    68,   156,   156,
     156,   156,    92,   156,   120,   129,    34,    75,    69,   120,
      16,   121,   121,   122,   122,   124,   124,   124,   124,   124,
     124,   125,   125,   126,   126,   126,   156,   120,   120,    14,
      13,    15,    92,    92,    17,   101,    92,   104,    14,    14,
     120,   120,   120,   106,    16,    58,   120,    15,    39,    18,
      68,    70,    16,    13,    15,    10,   171,    33,    71,    14,
      69,    75,    18,   160,   160,    25,   140,   162,   163,    25,
      13,    34,   131,    69,    34,    34,    17,   143,   142,    10,
     147,   148,    15,    69,    92,    92,    42,    51,    54,   116,
     117,    25,    18,    16,   107,   120,   120,    16,    16,    16,
     145,   146,   144,    17,   140,   120,   156,    18,    69,    75,
     156,   129,    16,    17,   151,   148,    15,   106,   106,   120,
      39,    52,   116,   120,   120,    42,    69,    57,    13,    34,
      18,    69,   120,   163,    69,   149,    39,    39,    52,    14,
     106,    39,    57,   106,    16,   146,   120,    77,    78,    98,
     150,   106,   106,    39,   120,    39,    65,    79,    79,    65,
     152,    39,    42,   172,    98,    98,   120,    11,   106,   156,
     140,   153,   154,    39,    14,    15,    13,    17,   143,    12,
     153,   153,    15
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 205 "readnet-syntax.yy"
    { F = NULL; }
    break;

  case 3:
#line 206 "readnet-syntax.yy"
    { F = (yyvsp[(4) - (4)].form); }
    break;

  case 4:
#line 207 "readnet-syntax.yy"
    {
    F = NULL;
    Globals::CheckPlace = (yyvsp[(5) - (5)].pl);
#ifdef STUBBORN
    Globals::Transitions[0]->StartOfStubbornList = NULL;
    int i;
    for (i = 0; Globals::CheckPlace->PreTransitions[i]; i++) {
        Globals::CheckPlace->PreTransitions[i]->instubborn = true;
        Globals::CheckPlace->PreTransitions[i]->NextStubborn = Globals::Transitions[0]->StartOfStubbornList;
        Globals::Transitions[0]->StartOfStubbornList = Globals::CheckPlace->PreTransitions[i];
    }
    Globals::Transitions[0]->EndOfStubbornList = LastAttractor = Globals::CheckPlace->PreTransitions[0];
#endif
    }
    break;

  case 5:
#line 221 "readnet-syntax.yy"
    {
        F = NULL;
        Globals::CheckTransition = (yyvsp[(5) - (5)].tr);
#ifdef STUBBORN
        Globals::Transitions[0]->EndOfStubbornList = LastAttractor = Globals::Transitions[0]->StartOfStubbornList = Globals::CheckTransition;
        Globals::CheckTransition->NextStubborn = NULL;
        Globals::CheckTransition->instubborn = true;
#endif
    }
    break;

  case 6:
#line 230 "readnet-syntax.yy"
    { F = NULL; }
    break;

  case 7:
#line 231 "readnet-syntax.yy"
    { F = NULL; }
    break;

  case 8:
#line 236 "readnet-syntax.yy"
    { LocalTable = new SymbolTab(2); }
    break;

  case 9:
#line 241 "readnet-syntax.yy"
    {
        TS = (TrSymbol*) TransitionTable->lookup((yyvsp[(1) - (1)].str));
        if (!TS) {
            yyerrors((yyvsp[(1) - (1)].str), "transition '%s' does not exist", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        if (TS->vars && TS->vars->card) {
            yyerrors((yyvsp[(1) - (1)].str), "high-level transition '%s' requires firing mode", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.tr) = TS->transition;
    }
    break;

  case 10:
#line 251 "readnet-syntax.yy"
    {
        unsigned int card;
        fmode* fm;
        for (card = 0, fm = (yyvsp[(3) - (4)].fm); fm; fm = fm->next, card++);
        if (card != (yyvsp[(1) - (4)].ts)->vars->card) {
            yyerror("firing mode incomplete");
        }
        char** cc = new char* [ card + 10];
        char** inst = new char* [ card + 10];
        unsigned int len = strlen((yyvsp[(1) - (4)].ts)->name) + 4;
        unsigned int j = 0;
        for (unsigned int i = 0; i < LocalTable->size; i++) {
            for (VS = (VaSymbol*)(LocalTable->table[i]); VS; VS = (VaSymbol*)(VS->next)) {
                for (fm = (yyvsp[(3) - (4)].fm); fm; fm = fm->next) {
                    if (fm->v == VS) {
                        break;
                    }
                }
                if (!fm) {
                    yyerror("firing mode incomplete");
                }
                UValue* vl = fm->t->evaluate();
                UValue* pl = VS->var->type->make();
                pl->assign(vl);
                cc[j] = pl->text();
                inst[j] = new char [strlen(VS->name) + strlen(cc[j]) + 20];
                strcpy(inst[j], VS->name);
                strcpy(inst[j] + strlen(inst[j]), "=");
                strcpy(inst[j] + strlen(inst[j]), cc[j]);
                len += strlen(inst[j]) + 1;
                j++;
            }
        }
        char* llt = new char[len + 20];
        strcpy(llt, (yyvsp[(1) - (4)].ts)->name);
        strcpy(llt + strlen(llt), ".[");
        for (j = 0; j < card; j++) {
            strcpy(llt + strlen(llt), inst[j]);
            strcpy(llt + strlen(llt), "|");
        }
        strcpy(llt + (strlen(llt) - 1), "]");
        TS = (TrSymbol*) TransitionTable->lookup(llt);
        if (!TS) {
            yyerrors(llt, "transition instance '%s' does not exist", _cimportant_(llt));
        }
        if (TS->vars && TS->vars->card) {
            yyerror("high-level and low-level transition names mixed up");
        }
        (yyval.tr) = TS->transition;
    }
    break;

  case 11:
#line 305 "readnet-syntax.yy"
    {
        TS = (TrSymbol*) TransitionTable->lookup((yyvsp[(1) - (2)].str));
        if (!TS) {
            yyerrors((yyvsp[(1) - (2)].str), "high-level transition '%s' does not exist", _cimportant_((yyvsp[(1) - (2)].str)));
        }
        if ((!(TS->vars) || TS->vars->card == 0)) {
            yyerrors((yyvsp[(1) - (2)].str), "high-level transition '%s' requires firing mode", _cimportant_((yyvsp[(1) - (2)].str)));
        }
        (yyval.ts) = TS;
        LocalTable = TS->vars;
    }
    break;

  case 12:
#line 320 "readnet-syntax.yy"
    {
        VS = (VaSymbol*) LocalTable->lookup((yyvsp[(1) - (3)].str));
        if (!VS) {
            yyerrors(yytext, "transition '%s' does not have this variable", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!(VS->var->type->iscompatible((yyvsp[(3) - (3)].ex)->type))) {
            yyerrors(yytext, "expression not compatible with variable of transition '%s'", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        (yyval.fm) = new fmode(VS, (yyvsp[(3) - (3)].ex), NULL);
    }
    break;

  case 13:
#line 330 "readnet-syntax.yy"
    {
        VS = (VaSymbol*) LocalTable->lookup((yyvsp[(3) - (5)].str));
        if (!VS) {
            yyerrors(yytext, "transition '%s' does not have this variable", _cimportant_((yyvsp[(3) - (5)].str)));
        }
        if (!(VS->var->type->iscompatible((yyvsp[(5) - (5)].ex)->type))) {
            yyerrors(yytext, "expression not compatible with variable of transition '%s'", _cimportant_((yyvsp[(3) - (5)].str)));
        }
        (yyval.fm) = new fmode(VS, (yyvsp[(5) - (5)].ex), (yyvsp[(1) - (5)].fm));
        for (fmode* fm = (yyvsp[(1) - (5)].fm); fm ; fm = fm->next) {
            if (fm->v == (yyval.fm)->v) {
                yyerror("variable appears twice in firing mode");
            }
        }
    }
    break;

  case 14:
#line 349 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (1)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (1)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        if (PS->sort) {
            yyerrors((yyvsp[(1) - (1)].str), "high-level '%s' place requires instance", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.pl) = PS->place;
    }
    break;

  case 15:
#line 359 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!(PS->sort)) {
            yyerrors((yyvsp[(1) - (3)].str), "low-level place '%s' does not require an instance", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!(PS->sort->iscompatible((yyvsp[(3) - (3)].ex)->type))) {
            yyerrors((yyvsp[(1) - (3)].str), "place color (%s) not compatible to sort of place '%s' (%s)",
                _cimportant_(getUTypeName(PS->sort->tag)), _cimportant_(getUTypeName((yyvsp[(3) - (3)].ex)->type->tag)), _cimportant_((yyvsp[(1) - (3)].str)));
        }
        UValue* vl = (yyvsp[(3) - (3)].ex)->evaluate();
        UValue* pl = PS->sort->make();
        pl->assign(vl);
        char* inst = pl->text();
        char* ll = new char [strlen(PS->name) + strlen(inst) + 20];
        strcpy(ll, PS->name);
        strcpy(ll + strlen(ll), ".");
        strcpy(ll + strlen(ll), inst);
        PS = (PlSymbol*) PlaceTable->lookup(ll);
        if (!PS) {
            yyerrors(ll, "place instance '%s' does not exist", _cimportant_(ll));
        }
        if (PS->sort) {
            yyerror("mixed up high-level and low-level place names");
        }
        (yyval.pl) = PS->place;
    }
    break;

  case 19:
#line 399 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(1); }
    break;

  case 23:
#line 410 "readnet-syntax.yy"
    {
        // sort symbols are globally visible. A sort entry in the
        // symbol table relates a name to a sort description (UType)
        SoSymbol* s;
        if ((s = (SoSymbol*)(GlobalTable->lookup((yyvsp[(1) - (4)].str))))) {
            yyerrors((yyvsp[(1) - (4)].str), "sort symbol name '%s' already used", _cimportant_((yyvsp[(1) - (4)].str)));
        }
        s = new SoSymbol((yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].t));
    }
    break;

  case 24:
#line 423 "readnet-syntax.yy"
    { (yyval.t) = TheBooType; }
    break;

  case 25:
#line 424 "readnet-syntax.yy"
    {
        // assign an additional name to an existing sort
        SoSymbol* s = (SoSymbol*)(GlobalTable->lookup((yyvsp[(1) - (1)].str)));
        if (!s) {
            yyerrors((yyvsp[(1) - (1)].str), "undefined sort name '%s'", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        if (s->kind != so) {
            yyerrors((yyvsp[(1) - (1)].str), "sort name expected, but '%s' is not a sort", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.t) = s->type;
    }
    break;

  case 26:
#line 435 "readnet-syntax.yy"
    {
        (yyval.t) = new URecType((yyvsp[(2) - (3)].rcl));
    }
    break;

  case 27:
#line 438 "readnet-syntax.yy"
    {
        // index type must be scalar
        if ((yyvsp[(2) - (4)].t)->tag != boo && (yyvsp[(2) - (4)].t)->tag != num && (yyvsp[(2) - (4)].t)->tag != enu) {
            yyerrors(yytext, "non-scalar type '%s' as index of array", _cimportant_(getUTypeName((yyvsp[(2) - (4)].t)->tag)));
        }
        (yyval.t) = new UArrType((yyvsp[(2) - (4)].t), (yyvsp[(4) - (4)].t));
    }
    break;

  case 28:
#line 445 "readnet-syntax.yy"
    {
        // integer interval
        const unsigned int l = atoi((yyvsp[(2) - (5)].str));
        const unsigned int r = atoi((yyvsp[(4) - (5)].str));
        if (l > r) {
            yyerrors(yytext, "negative range in integer type: lower bound (%d) greater than upper bound (%d)", l, r);
        }
        (yyval.t) = new UNumType(l, r);
    }
    break;

  case 29:
#line 454 "readnet-syntax.yy"
    {
        (yyval.t) = new UEnuType((yyvsp[(2) - (3)].el));
    }
    break;

  case 31:
#line 462 "readnet-syntax.yy"
    { 
        (yyvsp[(1) - (2)].el)->next = (yyvsp[(2) - (2)].el);
        (yyval.el) = (yyvsp[(1) - (2)].el);
    }
    break;

  case 32:
#line 470 "readnet-syntax.yy"
    {
        EnSymbol* e = (EnSymbol*) GlobalTable->lookup((yyvsp[(1) - (1)].str));
        if (e) {
            yyerrors((yyvsp[(1) - (1)].str), "element name '%s' of enumeration already used", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        e = new EnSymbol((yyvsp[(1) - (1)].str));
        (yyval.el) = new UEnList(e);
    }
    break;

  case 34:
#line 483 "readnet-syntax.yy"
    {
        (yyvsp[(2) - (2)].rcl)->next = (yyvsp[(1) - (2)].rcl);
        (yyval.rcl) = (yyvsp[(2) - (2)].rcl);
    }
    break;

  case 35:
#line 491 "readnet-syntax.yy"
    {
        RcSymbol* r = (RcSymbol*) GlobalTable->lookup((yyvsp[(1) - (4)].str));
        if (r) {
            yyerrors((yyvsp[(1) - (4)].str), "record component name '%s' already used", _cimportant_((yyvsp[(1) - (4)].str)));
        }
        r = new RcSymbol((yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].t));
        (yyval.rcl) = new URcList(r, (yyvsp[(3) - (4)].t), NULL);
    }
    break;

  case 36:
#line 503 "readnet-syntax.yy"
    {
        (yyvsp[(1) - (3)].fu)->body = (yyvsp[(3) - (3)].stm);
        (yyvsp[(1) - (3)].fu)->localsymb = LocalTable;
    }
    break;

  case 41:
#line 523 "readnet-syntax.yy"
    {
        for (IdList* il = (yyvsp[(1) - (4)].idl); il; il = il->next) {
            VaSymbol* v;
            UVar* vvv;
            if ((v = (VaSymbol*)(LocalTable->lookup(il->name)))) {
                yyerrors(il->name, "variable name '%s' already used", _cimportant_(il->name));
            }
            vvv = new UVar((yyvsp[(3) - (4)].t));
            v = new VaSymbol(il->name, vvv);
        }
    }
    break;

  case 42:
#line 538 "readnet-syntax.yy"
    {
        (yyval.idl) = new IdList((yyvsp[(1) - (1)].str), NULL);
    }
    break;

  case 43:
#line 541 "readnet-syntax.yy"
    {
        (yyval.idl) = new IdList((yyvsp[(1) - (3)].str), (yyvsp[(3) - (3)].idl));
    }
    break;

  case 44:
#line 548 "readnet-syntax.yy"
    {
        UFunction* f;
        FcSymbol* fs = (FcSymbol*) GlobalTable->lookup((yyvsp[(1) - (6)].str));
        if (fs) {
            yyerrors((yyvsp[(1) - (6)].str), "function name '%s' already used", _cimportant_((yyvsp[(1) - (6)].str)));
        }
        CurrentFunction = f = new UFunction();
        fs = new FcSymbol((yyvsp[(1) - (6)].str), f);
        f->type = (yyvsp[(6) - (6)].t);
        f->localsymb = LocalTable;
        f->result = NULL;
        f->resultstack = NULL;
        f->arity = LocalTable->card;
        f->formalpar = new UVar* [f->arity + 5];
        int i;
        i = 0;
        for (unsigned int j = 0; j < LocalTable->size; j++) {
            Symbol* s;
            for (s = LocalTable->table[j]; s; s = s->next) {
                f->formalpar[(f->arity - 1) - i++] = ((VaSymbol*) s)->var;
            }
        }

        (yyval.fu) = f;
    }
    break;

  case 48:
#line 582 "readnet-syntax.yy"
    {
        for (IdList* il = (yyvsp[(1) - (3)].idl); il; il = il->next) {
            VaSymbol* v;
            UVar* vvv;
            if ((v = (VaSymbol*)(LocalTable->lookup(il->name)))) {
                yyerrors(il->name, "variable name '%s' already used", _cimportant_(il->name));
            }
            vvv = new UVar((yyvsp[(3) - (3)].t));
            v = new VaSymbol(il->name, vvv);

        }
    }
    break;

  case 49:
#line 598 "readnet-syntax.yy"
    { (yyval.stm) = (yyvsp[(2) - (3)].stm); }
    break;

  case 51:
#line 604 "readnet-syntax.yy"
    { 
        UStatement* s = new USequenceStatement;
        ((USequenceStatement*) s)->first = (yyvsp[(1) - (3)].stm);
        ((USequenceStatement*) s)->second = (yyvsp[(3) - (3)].stm);
        (yyval.stm) = s;
    }
    break;

  case 61:
#line 627 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (5)].ex)->type->tag != boo) {
            yyerrors(yytext, "while condition must be %s, but is %s",
                _cimportant_("Boolean"), _cimportant_(getUTypeName((yyvsp[(2) - (5)].ex)->type->tag)));
        }
        (yyval.stm) = new UWhileStatement;
        ((UWhileStatement*) (yyval.stm))->cond = (yyvsp[(2) - (5)].ex);
        ((UWhileStatement*) (yyval.stm))->body = (yyvsp[(4) - (5)].stm);
    }
    break;

  case 62:
#line 640 "readnet-syntax.yy"
    {
        if ((yyvsp[(4) - (5)].ex)->type->tag != boo) {
            yyerrors(yytext, "repeat condition must be %s, but is %s",
                _cimportant_("Boolean"), _cimportant_(getUTypeName((yyvsp[(4) - (5)].ex)->type->tag)));
        }
        (yyval.stm) = new URepeatStatement;
        ((URepeatStatement*) (yyval.stm))->cond = (yyvsp[(4) - (5)].ex);
        ((URepeatStatement*) (yyval.stm))->body = (yyvsp[(2) - (5)].stm);
    }
    break;

  case 63:
#line 653 "readnet-syntax.yy"
    {
        VaSymbol* v = (VaSymbol*) LocalTable->lookup((yyvsp[(2) - (9)].str));
        if (!v) {
            yyerrors((yyvsp[(2) - (9)].str), "loop variable '%s' not declared", _cimportant_((yyvsp[(2) - (9)].str)));
        }
        (yyval.stm) = new UForStatement;
        ((UForStatement*) (yyval.stm))->var = v->var;
        if (!(v->var->type->iscompatible((yyvsp[(4) - (9)].ex)->type))) {
            yyerrors(yytext, "initial expression of for statement (%s) is not compatible to counter variable (%s)",
                _cimportant_(getUTypeName(v->var->type->tag)), _cimportant_(getUTypeName((yyvsp[(4) - (9)].ex)->type->tag)));
        }
        if (!(v->var->type->iscompatible((yyvsp[(6) - (9)].ex)->type))) {
            yyerrors(yytext, "exit expression of for statement (%s) is not compatible to counter variable (%s)",
              _cimportant_(getUTypeName(v->var->type->tag)), _cimportant_(getUTypeName((yyvsp[(6) - (9)].ex)->type->tag)));
        }
        ((UForStatement*) (yyval.stm))->init = (yyvsp[(4) - (9)].ex);
        ((UForStatement*) (yyval.stm))->finit = (yyvsp[(6) - (9)].ex);
        ((UForStatement*) (yyval.stm))->body = (yyvsp[(8) - (9)].stm);
    }
    break;

  case 64:
#line 676 "readnet-syntax.yy"
    {
        VaSymbol* v;
        v = (VaSymbol*) LocalTable->lookup((yyvsp[(3) - (6)].str));
        if (!v) {
            yyerrors((yyvsp[(3) - (6)].str), "loop variable '%s' not declared", _cimportant_((yyvsp[(3) - (6)].str)));
        }
        (yyval.stm) = new UForallStatement;
        ((UForallStatement*) (yyval.stm))->var = v->var;
        ((UForallStatement*) (yyval.stm))->body = (yyvsp[(5) - (6)].stm);
    }
    break;

  case 65:
#line 690 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (5)].ex)->type->tag != boo) {
            yyerrors(yytext, "condition in if statement must be %s, but is %s",
                _cimportant_("Boolean"), _cimportant_(getUTypeName((yyvsp[(2) - (5)].ex)->type->tag)));
        }
        (yyval.stm) = new UConditionalStatement;
        ((UConditionalStatement*) (yyval.stm))->cond = (yyvsp[(2) - (5)].ex);
        ((UConditionalStatement*) (yyval.stm))->yes = (yyvsp[(4) - (5)].stm);
        ((UConditionalStatement*) (yyval.stm))->no = new UNopStatement;
    }
    break;

  case 66:
#line 700 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (7)].ex)->type->tag != boo) {
            yyerrors(yytext, "condition in if statement must be %s, but is %s",
                _cimportant_("Boolean"), _cimportant_(getUTypeName((yyvsp[(2) - (7)].ex)->type->tag)));
        }
        (yyval.stm) = new UConditionalStatement;
        ((UConditionalStatement*) (yyval.stm))->cond = (yyvsp[(2) - (7)].ex);
        ((UConditionalStatement*) (yyval.stm))->yes = (yyvsp[(4) - (7)].stm);
        ((UConditionalStatement*) (yyval.stm))->no = (yyvsp[(6) - (7)].stm);
    }
    break;

  case 67:
#line 714 "readnet-syntax.yy"
    {
        if (!((yyvsp[(2) - (2)].ex)->type->iscompatible(CurrentFunction->type))) {
            yyerrors(yytext, "returned value (%s) incompatible to function type (%s)",
              _cimportant_(getUTypeName((yyvsp[(2) - (2)].ex)->type->tag)), _cimportant_(getUTypeName(CurrentFunction->type->tag)));
        }
        (yyval.stm) = new UReturnStatement;
        ((UReturnStatement*) (yyval.stm))->fct = CurrentFunction;
        ((UReturnStatement*) (yyval.stm))->exp = (yyvsp[(2) - (2)].ex);
    }
    break;

  case 68:
#line 727 "readnet-syntax.yy"
    {
        (yyval.stm) = new UExitStatement;
        ((UExitStatement*) (yyval.stm))->fct = CurrentFunction;
    }
    break;

  case 69:
#line 735 "readnet-syntax.yy"
    {
        unsigned int crd;
        case_list* l;
        for (l = (yyvsp[(3) - (4)].cl), crd = 0; l; l = l->next, crd++) {
            if (!((yyvsp[(2) - (4)].ex)->type->iscompatible(l->exp->type))) {
                yyerrors(yytext, "case item (%s) incompatible to case expression (%s)",
                  _cimportant_(getUTypeName((yyvsp[(2) - (4)].ex)->type->tag)), _cimportant_(getUTypeName(l->exp->type->tag)));
            }
        }
        (yyval.stm) = new UCaseStatement;
        ((UCaseStatement*) (yyval.stm))->exp = (yyvsp[(2) - (4)].ex);
        ((UCaseStatement*) (yyval.stm))->cond = new UExpression* [crd + 10];
        ((UCaseStatement*) (yyval.stm))->yes = new UStatement* [crd + 10];
        ((UCaseStatement*) (yyval.stm))->def = new UNopStatement;
        for (l = (yyvsp[(3) - (4)].cl), crd = 0; l; l = l->next, crd++) {
            ((UCaseStatement*) (yyval.stm))->cond[crd] = l->exp;
            ((UCaseStatement*) (yyval.stm))->yes[crd] = l->stm;
        }
        ((UCaseStatement*) (yyval.stm))->card = crd;
    }
    break;

  case 70:
#line 755 "readnet-syntax.yy"
    {
        unsigned int crd;
        case_list* l;
        for (l = (yyvsp[(3) - (6)].cl), crd = 0; l; l = l->next, crd++) {
            if (!((yyvsp[(2) - (6)].ex)->type->iscompatible(l->exp->type))) {
                yyerrors(yytext, "case item (%s) incompatible to case expression (%s)",
                  _cimportant_(getUTypeName((yyvsp[(2) - (6)].ex)->type->tag)), _cimportant_(getUTypeName(l->exp->type->tag)));
            }
        }
        (yyval.stm) = new UCaseStatement;
        ((UCaseStatement*) (yyval.stm))->exp = (yyvsp[(2) - (6)].ex);
        ((UCaseStatement*) (yyval.stm))->cond = new UExpression* [crd + 10];
        ((UCaseStatement*) (yyval.stm))->yes = new UStatement* [crd + 10];
        ((UCaseStatement*) (yyval.stm))->def = (yyvsp[(5) - (6)].stm);
        for (l = (yyvsp[(3) - (6)].cl), crd = 0; l; l = l->next, crd++) {
            ((UCaseStatement*) (yyval.stm))->cond[crd] = l->exp;
            ((UCaseStatement*) (yyval.stm))->yes[crd] = l->stm;
        }
        ((UCaseStatement*) (yyval.stm))->card = crd;
    }
    break;

  case 71:
#line 779 "readnet-syntax.yy"
    { (yyval.cl) = NULL; }
    break;

  case 72:
#line 780 "readnet-syntax.yy"
    { (yyvsp[(1) - (2)].cl)->next = (yyvsp[(2) - (2)].cl); (yyval.cl) = (yyvsp[(1) - (2)].cl); }
    break;

  case 73:
#line 785 "readnet-syntax.yy"
    {
        (yyval.cl) = new case_list((yyvsp[(4) - (4)].stm), (yyvsp[(2) - (4)].ex), NULL);
    }
    break;

  case 74:
#line 792 "readnet-syntax.yy"
    {
        if (!((yyvsp[(1) - (3)].lval)->type->iscompatible((yyvsp[(3) - (3)].ex)->type))) {
            yyerrors(yytext, "incompatible types in assignment (%s vs. %s)",
              _cimportant_(getUTypeName((yyvsp[(1) - (3)].lval)->type->tag)), _cimportant_(getUTypeName((yyvsp[(3) - (3)].ex)->type->tag)));
        }
        (yyval.stm) = new UAssignStatement;
        ((UAssignStatement*) (yyval.stm))->left = (yyvsp[(1) - (3)].lval);
        ((UAssignStatement*) (yyval.stm))->right = (yyvsp[(3) - (3)].ex);
    }
    break;

  case 75:
#line 805 "readnet-syntax.yy"
    {
        VaSymbol* v = (VaSymbol*)(LocalTable->lookup((yyvsp[(1) - (1)].str)));
        if (!v) {
            yyerrors((yyvsp[(1) - (1)].str), "variable '%s' not defined", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.lval) = new UVarLVal;
        ((UVarLVal*) (yyval.lval))->var = v->var;
        (yyval.lval)->type = ((UVarLVal*) (yyval.lval))->var->type;
    }
    break;

  case 76:
#line 814 "readnet-syntax.yy"
    {
        if ((yyvsp[(1) - (4)].lval)->type->tag != arr) {
            yyerrors(yytext, "component of '%s' referenced which is not an array, but %s", (yyvsp[(1) - (4)].lval), _cimportant_(getUTypeName((yyvsp[(1) - (4)].lval)->type->tag)));
        }
        if (((yyvsp[(3) - (4)].ex)->type->tag != boo) && ((yyvsp[(3) - (4)].ex)->type->tag != num) && ((yyvsp[(3) - (4)].ex)->type->tag != enu)) {
            yyerrors(yytext, "non-scalar expression (%s) for array index", _cimportant_(getUTypeName((yyvsp[(3) - (4)].ex)->type->tag)));
        }
        (yyval.lval) = new UArrayLVal;
        (yyval.lval)->type = ((UArrType*)((yyvsp[(1) - (4)].lval)->type))->component;
        ((UArrayLVal*) (yyval.lval))->indextype = ((UArrType*)((yyvsp[(1) - (4)].lval)->type))->index;
        ((UArrayLVal*) (yyval.lval))->parent = (yyvsp[(1) - (4)].lval);
        ((UArrayLVal*) (yyval.lval))->idx = (yyvsp[(3) - (4)].ex);
    }
    break;

  case 77:
#line 827 "readnet-syntax.yy"
    {
        RcSymbol* r = (RcSymbol*)(GlobalTable->lookup((yyvsp[(3) - (3)].str)));
        if ((!r) || (r->kind != rc)) {
            yyerrors((yyvsp[(3) - (3)].str), "record component '%s' unknown", _cimportant_((yyvsp[(3) - (3)].str)));
        }
        if ((yyvsp[(1) - (3)].lval)->type->tag != rec) {
            yyerrors((yyvsp[(3) - (3)].str), "component '%s' of something not a record referenced", _cimportant_((yyvsp[(3) - (3)].str)));
        }
        if (r->index >= ((URecType*)((yyvsp[(1) - (3)].lval)->type))->card || (r->type != ((URecType*)((yyvsp[(1) - (3)].lval)->type))->component[r->index])) {
            yyerrors((yyvsp[(3) - (3)].str), "record type does not have a component '%s'", _cimportant_((yyvsp[(3) - (3)].str)));
        }
        (yyval.lval) = new URecordLVal;
        (yyval.lval)->type = ((URecType*)((yyvsp[(1) - (3)].lval)->type))->component[r->index];
        ((URecordLVal*) (yyval.lval))->parent = (yyvsp[(1) - (3)].lval);
        ((URecordLVal*) (yyval.lval))->offset = r->index;
    }
    break;

  case 78:
#line 847 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, boo)) {
            yyerror("Boolean implication operator applied to non-Boolean operands");
        }
        UDivExpression* e = new UDivExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 79:
#line 857 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, boo)) {
            yyerror("Boolean operator applied to non-Boolean operands");
        }
        USubExpression* e = new USubExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 81:
#line 872 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, boo)) {
            yyerror("Boolean conjunction operator applied to non-Boolean operands");
        }
        UMulExpression* e = new UMulExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 82:
#line 882 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, boo)) {
            yyerror("Boolean disjunction operator applied to non-Boolean operands");
        }
        UAddExpression* e = new UAddExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 84:
#line 897 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(2) - (2)].ex)->type, boo)) {
            yyerror("Boolean negation operator applied to non-Boolean operand");
        }
        UNegExpression* e = new UNegExpression;
        e->left = (yyvsp[(2) - (2)].ex);
        e->type = (yyvsp[(2) - (2)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 86:
#line 911 "readnet-syntax.yy"
    {
        UEqualExpression* e = new UEqualExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 87:
#line 918 "readnet-syntax.yy"
    {
        UGreaterthanExpression* e = new UGreaterthanExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 88:
#line 925 "readnet-syntax.yy"
    {
        ULessthanExpression* e = new ULessthanExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 89:
#line 932 "readnet-syntax.yy"
    {
        UGreatereqqualExpression* e = new UGreatereqqualExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 90:
#line 939 "readnet-syntax.yy"
    {
        ULesseqqualExpression* e = new ULesseqqualExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 91:
#line 946 "readnet-syntax.yy"
    {
        UUneqqualExpression* e = new UUneqqualExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = TheBooType;
        (yyval.ex) = e;
    }
    break;

  case 93:
#line 958 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, num)) {
            yyerror("integer operator applied to non-integer operands");
        }
        UAddExpression* e = new UAddExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 94:
#line 968 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, num)) {
            yyerror("integer operator applied to non-integer operands");
        }
        USubExpression* e = new USubExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 96:
#line 983 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, num)) {
            yyerror("integer multiplication operator applied to non-integer operands");
        }
        UMulExpression* e = new UMulExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 97:
#line 993 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, num)) {
            yyerror("integer division operator applied to non-integer operands");
        }
        UDivExpression* e = new UDivExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 98:
#line 1003 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(1) - (3)].ex)->type, (yyvsp[(3) - (3)].ex)->type, num)) {
            yyerror("integer modulo operator applied to non-integer operands");
        }
        UModExpression* e = new UModExpression;
        e->left = (yyvsp[(1) - (3)].ex);
        e->right = (yyvsp[(3) - (3)].ex);
        e->type = (yyvsp[(1) - (3)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 100:
#line 1018 "readnet-syntax.yy"
    {
        if (!deep_compatible((yyvsp[(2) - (2)].ex)->type, num)) {
            yyerror("unary minus operator applied to non-integer operands");
        }
        UNegExpression* e = new UNegExpression;
        e->left = (yyvsp[(2) - (2)].ex);
        e->type = (yyvsp[(2) - (2)].ex)->type;
        (yyval.ex) = e;
    }
    break;

  case 102:
#line 1032 "readnet-syntax.yy"
    {
        Symbol* s = LocalTable->lookup((yyvsp[(1) - (1)].str));
        if (s) {
            // s is local variable
            VaSymbol* v = (VaSymbol*)s;
            ULVal* l = new UVarLVal;
            ((UVarLVal*) l)->var = v->var;
            ((UVarLVal*) l)->type = ((UVarLVal*) l)->var->type;
            ULvalExpression* e = new ULvalExpression;
            e->type = l->type;
            e->lval = l;
            (yyval.ex) = e;
        } else {
            // try global symbol
            s = GlobalTable->lookup((yyvsp[(1) - (1)].str));
            if (!s) {
                yyerrors((yyvsp[(1) - (1)].str), "identifier '%s' not defined", _cimportant_((yyvsp[(1) - (1)].str)));
            }
            if (s->kind != en) {
                yyerrors((yyvsp[(1) - (1)].str), "identifier '%s' of wrong kind", _cimportant_((yyvsp[(1) - (1)].str)));
            }
            EnSymbol* n = (EnSymbol*) s;
            UEnuconstantExpression* e = new UEnuconstantExpression;
            e->type = n->type;
            e->nu = n->ord;
            (yyval.ex) = e;
        }
    }
    break;

  case 103:
#line 1060 "readnet-syntax.yy"
    {
        RcSymbol* r = (RcSymbol*)(GlobalTable->lookup((yyvsp[(3) - (3)].str)));
        if ((!r) || (r->kind != rc)) {
            yyerror("record component unknown");
        }
        if ((yyvsp[(1) - (3)].lval)->type->tag != rec) {
            yyerror("component of something not a record referenced");
        }
        if (r->index >= ((URecType*)((yyvsp[(1) - (3)].lval)->type))->card || (r->type != ((URecType*)((yyvsp[(1) - (3)].lval)->type))->component[r->index])) {
            yyerror("record type does not have this component");
        }
        URecordLVal* l = new URecordLVal;
        l->type = ((URecType*)((yyvsp[(1) - (3)].lval)->type))->component[r->index];
        l->parent = (yyvsp[(1) - (3)].lval);
        l->offset = r->index;
        ULvalExpression* e = new ULvalExpression;
        e->type = l->type;
        e->lval = l;
        (yyval.ex) = e;
    }
    break;

  case 104:
#line 1080 "readnet-syntax.yy"
    {
        if ((yyvsp[(1) - (4)].lval)->type->tag != arr) {
            yyerrors(yytext, "component of something not an array (%s) referenced", _cimportant_(getUTypeName((yyvsp[(1) - (4)].lval)->type->tag)));
        }
        if (((yyvsp[(3) - (4)].ex)->type->tag != boo) && ((yyvsp[(3) - (4)].ex)->type->tag != num) && ((yyvsp[(3) - (4)].ex)->type->tag != enu)) {
            yyerrors(yytext, "non-scalar expression (%s) for array index", _cimportant_(getUTypeName((yyvsp[(3) - (4)].ex)->type->tag)));
        }
        UArrayLVal* a = new UArrayLVal;
        a->type = ((UArrType*)((yyvsp[(1) - (4)].lval)->type))->component;
        a->parent = (yyvsp[(1) - (4)].lval);
        a->indextype = ((UArrType*)((yyvsp[(1) - (4)].lval)->type))->index;
        a->idx = (yyvsp[(3) - (4)].ex);
        ULvalExpression* e = new ULvalExpression;
        e->type = a->type;
        e->lval = a;
        (yyval.ex) = e;
    }
    break;

  case 105:
#line 1097 "readnet-syntax.yy"
    { (yyval.ex) = (yyvsp[(2) - (3)].ex); }
    break;

  case 106:
#line 1098 "readnet-syntax.yy"
    {
        (yyval.ex) = new UTrueExpression;
        (yyval.ex)->type = TheBooType;
    }
    break;

  case 107:
#line 1102 "readnet-syntax.yy"
    {
        (yyval.ex) = new UFalseExpression;
        (yyval.ex)->type = TheBooType;
    }
    break;

  case 110:
#line 1108 "readnet-syntax.yy"
    {
        (yyval.ex) = new UIntconstantExpression;
        ((UIntconstantExpression*)(yyval.ex))->nu = atoi((yyvsp[(1) - (1)].str));
        (yyval.ex)->type = TheNumType;
    }
    break;

  case 111:
#line 1117 "readnet-syntax.yy"
    {
        FcSymbol* f = (FcSymbol*) GlobalTable->lookup((yyvsp[(1) - (4)].str));
        if (!f) {
            yyerrors((yyvsp[(1) - (4)].str), "undefined function '%s' called", _cimportant_((yyvsp[(1) - (4)].str)));
        }
        UCallExpression* e = new UCallExpression;
        e->fct = f->function;
        e->type = f->function->type;
        e->currentpar = new UExpression* [f->function->arity + 10];
        case_list* c;
        int i;
        for (i = 0, c = (yyvsp[(3) - (4)].cl); i < f-> function->arity; i++) {
            if (!c) {
                yyerrors(yytext, "too few arguments to function '%s'", _cimportant_((yyvsp[(1) - (4)].str)));
            }
            e->currentpar[i] = c->exp;
            if (!(c->exp->type->iscompatible(f->function->formalpar[i]->type))) {
                yyerrors(yytext, "type mismatch in call parameter %d of function '%s'", i+1, _cimportant_((yyvsp[(1) - (4)].str)));
            }
            c = c->next;
        }
        if (c) {
            yyerrors(yytext, "too many arguments to function '%s'", _cimportant_((yyvsp[(1) - (4)].str)));
        }
        (yyval.ex) = e;
    }
    break;

  case 112:
#line 1147 "readnet-syntax.yy"
    { (yyval.cl) = NULL; }
    break;

  case 113:
#line 1148 "readnet-syntax.yy"
    {
        (yyval.cl) = new case_list(NULL, (yyvsp[(1) - (1)].ex), NULL);
    }
    break;

  case 114:
#line 1151 "readnet-syntax.yy"
    {
        (yyval.cl) = new case_list(NULL, (yyvsp[(1) - (3)].ex), (yyvsp[(3) - (3)].cl));
    }
    break;

  case 115:
#line 1158 "readnet-syntax.yy"
    {
        unsigned int h;
        case_list* c;
        for (c = (yyvsp[(2) - (3)].cl), h = 0; c; c = c->next, h++);
        UNumType* it = new UNumType(1, h);
        UType* ct = (yyvsp[(2) - (3)].cl)->exp->type;
        UArrType* at = new UArrType(it, ct);
        UArrayExpression* e = new UArrayExpression;
        e->type = at;
        e->card = h;
        e->cont = new UExpression* [h + 10];
        int i;
        for (i = 0, c = (yyvsp[(2) - (3)].cl); i < (int)h; i++, c = c->next) {
            e->cont[i] = c->exp;
            if (!(ct->iscompatible(c->exp->type))) {
                yyerror("incompatible types in array value");
            }

        }
        (yyval.ex) = e;
    }
    break;

  case 116:
#line 1183 "readnet-syntax.yy"
    {
        (yyval.cl) = new case_list(NULL, (yyvsp[(1) - (1)].ex), NULL);
    }
    break;

  case 117:
#line 1186 "readnet-syntax.yy"
    {
        (yyval.cl) = new case_list(NULL, (yyvsp[(1) - (3)].ex), (yyvsp[(3) - (3)].cl));
    }
    break;

  case 120:
#line 1199 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (PS->sort) {
            // HL place, number nicht erlaubt
            yyerrors(yytext, "marking of high-level place '%s' must be a term expression", _cimportant_((yyvsp[(1) - (3)].str)));
        } else {
            // LL place, number ist als Anzahl zu interpretieren
            PS->place->target_marking += atoi((yyvsp[(3) - (3)].str));
        }
    }
    break;

  case 121:
#line 1212 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!PS->sort) {
            yyerrors((yyvsp[(1) - (3)].str), "multiterm expression not allowed for low-level place '%s'", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        UValue* pv = PS->sort->make();
        for (UTermList* tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl->next) { // do for all mt components
            // check type compatibility
            if (!(PS->sort->iscompatible(tl->t->type))) {
                yyerrors(yytext, "marking expression %s not compatible to sort %s of place '%s'",
                _cimportant_(getUTypeName(tl->t->type->tag)), _cimportant_(getUTypeName(PS->sort->tag)), _cimportant_((yyvsp[(1) - (3)].str)));
            }
            UValueList* vl = tl->t->evaluate();
            for (UValueList* currentvl = vl; currentvl; currentvl = currentvl->next) {
                pv->assign(currentvl->val); // type adjustment
                char* inst = pv->text();
                char* ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
                strcpy(ll, (yyvsp[(1) - (3)].str));
                strcpy(ll + strlen((yyvsp[(1) - (3)].str)), ".");
                strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
                PlSymbol* PSI = (PlSymbol*) PlaceTable->lookup(ll);
                if (!PSI) {
                    yyerrors(ll, "place instance '%s' does not exist", _cimportant_(ll));
                }
                PSI->place->target_marking += tl->mult;
            }
        }
    }
    break;

  case 122:
#line 1247 "readnet-syntax.yy"
    {LocalTable = NULL; }
    break;

  case 123:
#line 1248 "readnet-syntax.yy"
    {
        unsigned int i, h, j;
        // Create array of places
        Globals::Places = new Place* [PlaceTable->card + 10];
        Globals::CurrentMarking = new unsigned int [PlaceTable->card + 10];
        i = 0;
        for (h = 0; h < PlaceTable->size; h++) {
            for (Symbol* ss = PlaceTable->table[h]; ss; ss = ss->next) {
                if (!(((PlSymbol*) ss)->sort)) {
                    Globals::Places[i++] = ((PlSymbol*) ss)->place;
                }
            }
        }
        PlaceTable->card = i;
#ifdef WITHFORMULA
        for (i = 0; i < PlaceTable->card; i++) {
            Globals::Places[i]->propositions = NULL;
        }
#endif
        // Create array of transitions
        Globals::Transitions = new Transition* [TransitionTable->card + 10];
        i = 0;
        for (h = 0; h < TransitionTable->size; h++) {
            for (Symbol* ss = TransitionTable->table[h]; ss; ss = ss->next) {
                if (!(((TrSymbol*) ss)->vars)) {
                    Globals::Transitions[i++] = ((TrSymbol*) ss)->transition;
                }
            }
        }
        TransitionTable->card = i;
        // Create arc list of places pass 1 (count nr of arcs)
        for (i = 0; i < TransitionTable->card; i++) {
            for (j = 0; j < Globals::Transitions[i]->NrOfArriving; j++) {
                Globals::Transitions[i]->ArrivingArcs[j]->pl->NrOfLeaving++;
            }
            for (j = 0; j < Globals::Transitions[i]->NrOfLeaving; j++) {
                Globals::Transitions[i]->LeavingArcs[j]->pl->NrOfArriving++;
            }
        }
        // pass 2 (allocate arc arrays)
        for (i = 0; i < PlaceTable->card; i++) {
            Globals::Places[i]->ArrivingArcs = new Arc * [Globals::Places[i]->NrOfArriving + 10];
            Globals::Places[i]->NrOfArriving = 0;
            Globals::Places[i]->LeavingArcs = new Arc * [Globals::Places[i]->NrOfLeaving + 10];
            Globals::Places[i]->NrOfLeaving = 0;
        }
        // pass 3 (fill in arcs)
        for (i = 0; i < TransitionTable->card; i++) {
            for (j = 0; j < Globals::Transitions[i]->NrOfLeaving; j++) {
                Place* pl;
                pl = Globals::Transitions[i]->LeavingArcs[j]->pl;
                pl->ArrivingArcs[pl->NrOfArriving] = Globals::Transitions[i]->LeavingArcs[j];
                pl->NrOfArriving ++;
            }
            for (j = 0; j < Globals::Transitions[i]->NrOfArriving; j++) {
                Place* pl;
                pl = Globals::Transitions[i]->ArrivingArcs[j]->pl;
                pl->LeavingArcs[pl->NrOfLeaving] = Globals::Transitions[i]->ArrivingArcs[j];
                pl->NrOfLeaving ++;
            }
        }
        for (i = 0; i < TransitionTable->card; i++) {
#ifdef STUBBORN
            Globals::Transitions[i]->mustbeincluded = Globals::Transitions[i]->conflicting;
#if defined(EXTENDED) && defined(MODELCHECKING)
            Globals::Transitions[i]->lstfired = new unsigned int [10];
            Globals::Transitions[i]->lstdisabled = new unsigned int [10];
#endif
#endif
        }
#if defined(EXTENDED) && defined(MODELCHECKING)
        formulaindex = 0;
        currentdfsnum = 0;
#endif
        // initialize places
#ifdef STUBBORN
        for (i = 0; i < PlaceTable->card; i++) {
            Globals::Places[i]->initialize();
        }
#endif
        Globals::Transitions[0]->StartOfEnabledList = Globals::Transitions[0];
        // The following pieces of code initialize static attractor sets for
        // various problems.
#ifdef BOUNDEDNET
#ifdef STUBBORN
        // initialize list of pumping transitions
        LastAttractor = NULL;
        int p, c, a; // produced, consumed tokens, current arc
        for (i = 0; i < TransitionTable->card; i++) {
            // count produced tokens
            for (a = 0, p = 0; a < Globals::Transitions[i]->NrOfLeaving; a++) {
                p += Globals::Transitions[i]->LeavingArcs[a]->Multiplicity;
            }
            // count consumed tokens
            for (a = 0, c = 0; a < Globals::Transitions[i]->NrOfArriving; a++) {
                c += Globals::Transitions[i]->ArrivingArcs[a]->Multiplicity;
            }
            if (p > c) {
                Globals::Transitions[i]->instubborn = true;
                if (LastAttractor) {
                    Globals::Transitions[i]->NextStubborn =
                        Globals::Transitions[i]->StartOfStubbornList;
                    Globals::Transitions[i]->StartOfStubbornList = Globals::Transitions[i];
                } else {
                    Globals::Transitions[i]->StartOfStubbornList = LastAttractor = Globals::Transitions[i];
                    Globals::Transitions[i]->NextStubborn = NULL;
                }
            }
        }

#endif
#endif
    }
    break;

  case 126:
#line 1371 "readnet-syntax.yy"
    { CurrentCapacity = CAPACITY; }
    break;

  case 127:
#line 1372 "readnet-syntax.yy"
    { CurrentCapacity = 1; }
    break;

  case 128:
#line 1373 "readnet-syntax.yy"
    { CurrentCapacity = atoi((yyvsp[(2) - (3)].str)); }
    break;

  case 131:
#line 1384 "readnet-syntax.yy"
    {
        if (PlaceTable->lookup((yyvsp[(1) - (1)].str))) {
            yyerrors((yyvsp[(1) - (1)].str), "place '%s' name used twice", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        const unsigned int capacity = (CurrentCapacity > 0) ? logzwo(CurrentCapacity) : 32;
        P = new Place((yyvsp[(1) - (1)].str), CurrentCapacity, capacity);
        PS = new PlSymbol(P, NULL);
    }
    break;

  case 132:
#line 1392 "readnet-syntax.yy"
    {
        // high level place: unfold to all instances
        char* c;
        if (PlaceTable->lookup((yyvsp[(1) - (3)].str))) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' name used twice", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        c = new char [strlen((yyvsp[(1) - (3)].str)) + 10];
        strcpy(c, (yyvsp[(1) - (3)].str));
        PS = new PlSymbol(c, (yyvsp[(3) - (3)].t));

        // unfolding: creating low-level places
        UValue* v = (yyvsp[(3) - (3)].t)->make();
        do {
            char* lowtag = v->text();
            char* lowlevelplace = new char [strlen(c) + strlen(lowtag) + 20];
            strcpy(lowlevelplace, c);
            strcpy(lowlevelplace + strlen(c), ".");
            strcpy(lowlevelplace + strlen(c) + 1, lowtag);
            if (PlaceTable->lookup(lowlevelplace)) {
                yyerrors(lowlevelplace, "place instance '%s' name already used", _cimportant_(lowlevelplace));
            }
            const unsigned int capacity = (CurrentCapacity > 0) ? logzwo(CurrentCapacity) : 32;
            P = new Place(lowlevelplace, CurrentCapacity, capacity);
            PS = new PlSymbol(P, NULL);
            (*v)++;
        } while (!(v->isfirst()));
    }
    break;

  case 133:
#line 1423 "readnet-syntax.yy"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 134:
#line 1424 "readnet-syntax.yy"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 138:
#line 1436 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (PS->sort) {
            // HL place, number nicht erlaubt
            yyerrors(yytext, "marking of high-level place '%s' must be a term expression", _cimportant_((yyvsp[(1) - (3)].str)));
        } else {
            // LL place, number ist als Anzahl zu interpretieren
            *(PS->place) += atoi((yyvsp[(3) - (3)].str));
        }
    }
    break;

  case 139:
#line 1449 "readnet-syntax.yy"
    {
        UValueList* vl, * currentvl;
        PlSymbol* PSI;
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!PS->sort) {
            yyerrors((yyvsp[(1) - (3)].str), "multiterm expression not allowed for low-level place '%s'", _cimportant_((yyvsp[(1) - (3)].str)));
        }

        // unfolding: find marked low-level places
        UValue* pv = PS->sort->make();
        for (UTermList* tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl->next) { // do for all mt components
            // check type compatibility
            if (!(PS->sort->iscompatible(tl->t->type))) {
                yyerrors(yytext, "marking expression not compatible to sort of place '%s'", _cimportant_((yyvsp[(1) - (3)].str)));
            }
            vl = tl->t->evaluate();
            for (currentvl = vl; currentvl; currentvl = currentvl->next) {
                pv->assign(currentvl->val); // type adjustment
                char* inst = pv->text();
                char* ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
                strcpy(ll, (yyvsp[(1) - (3)].str));
                strcpy(ll + strlen((yyvsp[(1) - (3)].str)), ".");
                strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
                PSI = (PlSymbol*) PlaceTable->lookup(ll);
                if (!PSI) {
                    yyerrors(ll, "place instance '%s' does not exist", _cimportant_(ll));
                }
                (* PSI->place) += tl->mult;
            }
        }
    }
    break;

  case 140:
#line 1487 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist); }
    break;

  case 141:
#line 1488 "readnet-syntax.yy"
    { (yyvsp[(3) - (3)].tlist)->next = (yyvsp[(1) - (3)].tlist); (yyval.tlist) = (yyvsp[(3) - (3)].tlist); }
    break;

  case 142:
#line 1493 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist); }
    break;

  case 143:
#line 1494 "readnet-syntax.yy"
    {
        (yyvsp[(1) - (3)].tlist)->mult = atoi((yyvsp[(3) - (3)].str));
        (yyval.tlist) = (yyvsp[(1) - (3)].tlist);
    }
    break;

  case 144:
#line 1502 "readnet-syntax.yy"
    {
        if (!LocalTable) {
            yyerror("only constant terms are allowed in this context");
        }
        VS = (VaSymbol*)(LocalTable->lookup((yyvsp[(1) - (1)].str)));
        if (!VS) {
            yyerrors((yyvsp[(1) - (1)].str), "undeclared variable '%s' in term", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        UTermList* tl = new UTermList;
        tl->next = NULL;
        tl->mult = 1;
        UVarTerm* vt = new UVarTerm;
        tl->t = vt;
        vt->v = VS->var;
        vt->type = VS->var->type;
        (yyval.tlist) = tl;
    }
    break;

  case 145:
#line 1519 "readnet-syntax.yy"
    {
        FcSymbol* FS = (FcSymbol*) GlobalTable->lookup((yyvsp[(1) - (4)].str));
        if (!FS) {
            yyerrors((yyvsp[(1) - (4)].str), "operation symbol '%s' not declared", _cimportant_((yyvsp[(1) - (4)].str)));
        }
        if (FS->kind != fc) {
            yyerror("wrong symbol used as operation symbol");
        }
        unsigned int i;
        UTermList* l;
        for (i = 0, l = (yyvsp[(3) - (4)].tlist); l; i++, l = l->next) {
            ;
        }
        if ((int)i != FS->function->arity) {
            yyerrors(yytext, "function '%s' needs exactly %d arguments", _cimportant_((yyvsp[(1) - (4)].str)), FS->function->arity);
        }
        UTermList* tl = new UTermList;
        tl->next = NULL;
        tl->mult = 1;
        UOpTerm* ot = new UOpTerm;
        tl->t = ot;
        ot->arity = i;
        ot->f = FS->function;
        ot->sub = new UTerm* [i + 5];
        for (i = 0, l = (yyvsp[(3) - (4)].tlist); i < ot->arity; i++, l = l->next) {
            if (!(ot->f->formalpar[i]->type->iscompatible(l->t->type))) {
                yyerrors(yytext, "type mismatch in subterm %d: %s given, but %s expected",
                  i+1, _cimportant_(getUTypeName(l->t->type->tag)), _cimportant_(getUTypeName(ot->f->formalpar[i]->type->tag)));
            }
            ot->sub[i] = l->t;
        }
        ot->type = ot->f->type;
        (yyval.tlist) = tl;
    }
    break;

  case 146:
#line 1557 "readnet-syntax.yy"
    { (yyval.tlist) = NULL; }
    break;

  case 147:
#line 1558 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist); }
    break;

  case 148:
#line 1559 "readnet-syntax.yy"
    { (yyvsp[(1) - (3)].tlist)->next = (yyvsp[(3) - (3)].tlist); (yyval.tlist) = (yyvsp[(1) - (3)].tlist); }
    break;

  case 151:
#line 1570 "readnet-syntax.yy"
    {
        if (TransitionTable->lookup((yyvsp[(2) - (2)].str))) {
            yyerrors((yyvsp[(2) - (2)].str), "transition name '%s' used twice", _cimportant_((yyvsp[(2) - (2)].str)));
        }
    }
    break;

  case 152:
#line 1575 "readnet-syntax.yy"
    {
        unsigned int card;
        unsigned int i;
        //arc_list* current;
        /* 1. Transition anlegen */
        TS = new TrSymbol((yyvsp[(2) - (11)].str));
        TS->vars = LocalTable;
        TS->guard = (yyvsp[(5) - (11)].ex);

        // unfold HL transitions
        //->create transition instance for every assignment to the variables that
        //    matches the guard


        // init: initially, all variables have initial value

        while (1) {
            if (TS->guard) {
                UValue* v;
                v = TS->guard->evaluate();
                if (((UBooValue*)v)->v == false) {
                    goto nextass;
                }
            }
            // A) create LL transition with current variable assignment

            /* generate name */
            char* llt;
            if ((!LocalTable) || LocalTable->card == 0) {
                llt = TS->name;
                TS->vars = NULL;
            } else {
                char** assignment;
                unsigned int len;
                len = 0;
                assignment = new char * [LocalTable->card + 1000];
                VaSymbol* vs;
                unsigned int i, j;
                j = 0;
                for (i = 0; i < LocalTable->size; i++) {
                    for (vs = (VaSymbol*)(LocalTable->table[i]); vs ; vs = (VaSymbol*) vs->next) {
                        char* inst;
                        inst = vs->var->value->text();
                        assignment[j] = new char[strlen(vs->name) + 10 + strlen(inst)];
                        strcpy(assignment[j], vs->name);
                        strcpy(assignment[j] + strlen(vs->name), "=");
                        strcpy(assignment[j] + strlen(vs->name) + 1, inst);
                        len += strlen(assignment[j++]);
                    }
                }
                llt = new char [ strlen(TS->name)  + len + LocalTable->card + 1000];
                strcpy(llt, TS->name);
                strcpy(llt + strlen(llt), ".[");
                for (i = 0; i < LocalTable->card; i++) {
                    strcpy(llt + strlen(llt), assignment[i]);
                    strcpy(llt + strlen(llt), "|");
                }
                strcpy(llt + (strlen(llt) - 1), "]");
            }
            TrSymbol* TSI;
            if ((!LocalTable) || LocalTable->card == 0) {
                TSI = TS;
            } else {
                TSI = (TrSymbol*) TransitionTable->lookup(llt);
                if (TSI) {
                    yyerror("transition instance already exists");
                }
                TSI = new TrSymbol(llt);
                TSI->vars = NULL;
                TSI->guard = NULL;
            }
            T = TSI->transition = new Transition(TSI->name, (yyvsp[(4) - (11)].value));
            /* 2. Inliste eintragen */
            /* HL-Boegen in LL-Boegen uebersetzen und zur Liste hinzufuegen */
            arc_list* root;
            root = (yyvsp[(7) - (11)].al);
            for (arc_list* current = root; current; current = current->next) {
                if (current->mt) {
                    // traverse multiterm
                    UTermList* mc;
                    UValueList* vl;
                    UValueList* vc;
                    UValue* pv = current->place->sort->make();
                    for (mc = current->mt; mc ; mc = mc->next) {
                        vl = mc->t->evaluate();

                        for (vc = vl; vc; vc  = vc->next) {
                            char* inst;
                            char* ll;
                            pv->assign(vc->val);
                            inst = pv->text();
                            ll = new char [strlen(current->place->name) + strlen(inst) + 20];
                            strcpy(ll, current->place->name);
                            strcpy(ll + strlen(current->place->name), ".");
                            strcpy(ll + strlen(current->place->name) + 1, inst);
                            PS = (PlSymbol*) PlaceTable->lookup(ll);
                            if (!ll) {
                                yyerror("place instance does not exist");
                            }
                            if (PS->sort) {
                                yyerror("arcs to high-level places are not allowed");
                            }
                            arc_list* a = new arc_list(PS, NULL, mc->mult, root);
                            root = a;
                        }
                    }
                }
            }
            /* Anzahl der Boegen */
            arc_list* current;
            for (card = 0, current = root; current; card++, current = current->next);
            T->ArrivingArcs = new Arc * [card + 10];
            /* Schleife ueber alle Boegen */
            for (arc_list* current = root; current; current = current->next) {
                /* Bogen ist nur HL-Bogen */
                if (current->place->sort) {
                    continue;
                }
                /* Vielfachheit 0 */
                if (current->nu == 0) {
                    continue;
                }
                /* gibt es Bogen schon? */

                for (i = 0; i < T->NrOfArriving; i++) {
                    if (current->place->place == T->ArrivingArcs[i]->pl) {
                        /* Bogen existiert, nur Vielfachheit addieren */
                        *(T->ArrivingArcs[i]) += current->nu;
                        break;
                    }
                }
                if (i >= T->NrOfArriving) {
                    T->ArrivingArcs[T->NrOfArriving] = new Arc(T, current->place->place, true, current->nu);
                    T->NrOfArriving++;
                    current->place->place->references ++;
                }
            }
            /* 2. Outliste eintragen */
            root = (yyvsp[(10) - (11)].al);
            for (arc_list* current = root; current; current = current->next) {
                if (current->mt) {
                    // traverse multiterm
                    UTermList* mc;
                    UValueList* vl;
                    UValueList* vc;
                    UValue* pv = current->place->sort->make();
                    for (mc = current->mt; mc ; mc = mc->next) {
                        vl = mc->t->evaluate();
                        for (vc = vl; vc; vc  = vc->next) {
                            char* inst;
                            char* ll;
                            pv->assign(vc->val);
                            inst = pv->text();
                            ll = new char [strlen(current->place->name) + strlen(inst) + 20];
                            strcpy(ll, current->place->name);
                            strcpy(ll + strlen(current->place->name), ".");
                            strcpy(ll + strlen(current->place->name) + 1, inst);
                            PS = (PlSymbol*) PlaceTable->lookup(ll);
                            if (!ll) {
                                yyerror("place instance does not exist");
                            }
                            arc_list* a = new arc_list(PS, NULL, mc->mult, root);
                            root = a;
                        }
                    }
                }
            }
            /* Anzahl der Boegen */
            for (card = 0, current = root; current; card++, current = current->next) {
                ;
            }
            T->LeavingArcs = new Arc* [card + 10];
            /* Schleife ueber alle Boegen */
            for (arc_list* current = root; current; current = current->next) {
                /* Bogen ist nur HL-Bogen */
                if (current->place->sort) {
                    continue;
                }
                /* Vielfachheit 0 */
                if (current->nu == 0) {
                    continue;
                }
                /* gibt es Bogen schon? */

                for (i = 0; i < T->NrOfLeaving; i++) {
                    if (current->place->place == T->LeavingArcs[i]->pl) {
                        /* Bogen existiert, nur Vielfachheit addieren */
                        *(T->LeavingArcs[i]) += current->nu;
                        break;
                    }
                }
                if (i >= T->NrOfLeaving) {
                    T->LeavingArcs[T->NrOfLeaving] = new Arc(T, current->place->place, false, current->nu);
                    T->NrOfLeaving++;
                    current->place->place->references ++;
                }
            }
// B) switch to next assignment
nextass:
            if ((!LocalTable) || LocalTable->card == 0) {
                break;
            }
            unsigned int k;
            VaSymbol* vv;
            for (k = 0; k < LocalTable->size; k++) {
                for (vv = (VaSymbol*)(LocalTable->table[k]); vv; vv = (VaSymbol*)(vv->next)) {
                    (*(vv->var->value)) ++;
                    if (!(vv->var->value->isfirst())) {
                        break;
                    }
                }
                if (vv) {
                    break;
                }
            }
            if (!vv) {
                break;
            }
        }
    }
    break;

  case 153:
#line 1799 "readnet-syntax.yy"
    { (yyval.value) = 0; }
    break;

  case 154:
#line 1800 "readnet-syntax.yy"
    { (yyval.value) = 1; }
    break;

  case 155:
#line 1801 "readnet-syntax.yy"
    { (yyval.value) = 2; }
    break;

  case 156:
#line 1806 "readnet-syntax.yy"
    { LocalTable = new SymbolTab(256); }
    break;

  case 157:
#line 1807 "readnet-syntax.yy"
    { LocalTable = new SymbolTab(256); }
    break;

  case 158:
#line 1812 "readnet-syntax.yy"
    { (yyval.ex) = NULL; }
    break;

  case 159:
#line 1813 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (2)].ex)->type->tag != boo) {
            yyerror("guard expression must be Boolean");
        }
        (yyval.ex) = (yyvsp[(2) - (2)].ex);
    }
    break;

  case 160:
#line 1823 "readnet-syntax.yy"
    { (yyval.al) = NULL; }
    break;

  case 161:
#line 1824 "readnet-syntax.yy"
    { (yyval.al) = (yyvsp[(1) - (1)].al); }
    break;

  case 162:
#line 1825 "readnet-syntax.yy"
    { (yyvsp[(1) - (3)].al)->next = (yyvsp[(3) - (3)].al); (yyval.al) = (yyvsp[(1) - (3)].al); }
    break;

  case 163:
#line 1830 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (PS->sort) {
            yyerrors(yytext, "arc expression of high level place '%s' must be term expressions", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        (yyval.al) = new arc_list(PS, NULL, atoi((yyvsp[(3) - (3)].str)), NULL);
    }
    break;

  case 164:
#line 1840 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (3)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (3)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!(PS->sort)) {
            yyerrors((yyvsp[(1) - (3)].str), "low-level place '%s' requires numerical multiplicity", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        (yyval.al) = new arc_list(PS, (yyvsp[(3) - (3)].tlist), 0, NULL);
        for (UTermList* tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl->next) {
            if (!(PS->sort->iscompatible(tl->t->type))) {
                yyerrors((yyvsp[(1) - (3)].str), "type mismatch between place '%s' and arc expression", _cimportant_((yyvsp[(1) - (3)].str)));
            }
        }
    }
    break;

  case 165:
#line 1859 "readnet-syntax.yy"
    { 
        (yyval.ex) = new UIntconstantExpression();
        ((UIntconstantExpression*)(yyval.ex))->nu = atoi((yyvsp[(1) - (1)].str));
    }
    break;

  case 166:
#line 1863 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (3)].ex)->type->tag != num) {
            yyerror("integer expression expected");
        }
        (yyval.ex) = (yyvsp[(2) - (3)].ex);
    }
    break;

  case 167:
#line 1873 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = eq;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 168:
#line 1878 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = neq;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 169:
#line 1883 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = leq;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 170:
#line 1888 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = geq;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 171:
#line 1893 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = lt;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 172:
#line 1898 "readnet-syntax.yy"
    {
        ((hlatomicformula*) (yyvsp[(1) - (3)].form))->k = (yyvsp[(3) - (3)].ex);
        (yyvsp[(1) - (3)].form)->type = gt;
        (yyval.form) = (yyvsp[(1) - (3)].form);
    }
    break;

  case 173:
#line 1903 "readnet-syntax.yy"
    {
        (yyval.form) = new binarybooleanformula(conj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
    }
    break;

  case 174:
#line 1906 "readnet-syntax.yy"
    {
        (yyval.form) = new binarybooleanformula(disj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
    }
    break;

  case 175:
#line 1909 "readnet-syntax.yy"
    {
        (yyval.form) = new unarybooleanformula(neg, (yyvsp[(2) - (2)].form));
     }
    break;

  case 176:
#line 1912 "readnet-syntax.yy"
    {
        if ((yyvsp[(2) - (3)].ex)->type->tag != boo) {
            yyerror("formula requires Boolean expression");
        }
        (yyval.form) = new staticformula((yyvsp[(2) - (3)].ex));
    }
    break;

  case 177:
#line 1918 "readnet-syntax.yy"
    {
        (yyvsp[(2) - (4)].varsy)->name[0] = '0';
        (yyval.form) = new quantifiedformula(qe, (yyvsp[(2) - (4)].varsy)->var, (yyvsp[(4) - (4)].form));
    }
    break;

  case 178:
#line 1922 "readnet-syntax.yy"
    {
        (yyvsp[(2) - (4)].varsy)->name[0] = '0';
        (yyval.form) = new quantifiedformula(qa, (yyvsp[(2) - (4)].varsy)->var, (yyvsp[(4) - (4)].form));
    }
    break;

  case 179:
#line 1926 "readnet-syntax.yy"
    {
        (yyval.form) = (yyvsp[(2) - (3)].form);
    }
    break;

  case 180:
#line 1929 "readnet-syntax.yy"
    {
        (yyval.form) = new untilformula(eu, (yyvsp[(4) - (7)].form), (yyvsp[(6) - (7)].form), (transitionformula*) (yyvsp[(2) - (7)].form));
    }
    break;

  case 181:
#line 1932 "readnet-syntax.yy"
    {
        (yyval.form) = new untilformula(au, (yyvsp[(4) - (7)].form), (yyvsp[(6) - (7)].form), (transitionformula*) (yyvsp[(2) - (7)].form));
    }
    break;

  case 182:
#line 1935 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(eg, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 183:
#line 1938 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(ag, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 184:
#line 1941 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(ex, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 185:
#line 1944 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(ax, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 186:
#line 1947 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(ef, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 187:
#line 1950 "readnet-syntax.yy"
    {
        (yyval.form) = new unarytemporalformula(af, (yyvsp[(4) - (4)].form), (transitionformula*) (yyvsp[(2) - (4)].form));
    }
    break;

  case 188:
#line 1957 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (1)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (1)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        if (PS->sort) {
            yyerrors((yyvsp[(1) - (1)].str), "high-level place '%s' requires an instance", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.form) = new hlatomicformula(neq, PS, NULL);
    }
    break;

  case 189:
#line 1967 "readnet-syntax.yy"
    {
        PS = (PlSymbol*) PlaceTable->lookup((yyvsp[(1) - (5)].str));
        if (!PS) {
            yyerrors((yyvsp[(1) - (5)].str), "place '%s' does not exist", _cimportant_((yyvsp[(1) - (5)].str)));
        }
        if (!(PS->sort)) {
            yyerrors((yyvsp[(1) - (5)].str), "low-level place '%s' does not require an instance", _cimportant_((yyvsp[(1) - (5)].str)));
        }
        if (!(PS->sort->iscompatible((yyvsp[(4) - (5)].ex)->type))) {
            yyerrors((yyvsp[(1) - (5)].str), "place color incompatible to sort of place '%s'", _cimportant_((yyvsp[(1) - (5)].str)));
        }
        (yyval.form) = new hlatomicformula(neq, PS, (yyvsp[(4) - (5)].ex));
    }
    break;

  case 190:
#line 1984 "readnet-syntax.yy"
    {
        VS = (VaSymbol*) LocalTable->lookup((yyvsp[(1) - (3)].str));
        if (VS) {
            yyerrors((yyvsp[(1) - (3)].str), "variable used '%s' twice in formula", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        UVar* vv = new UVar((yyvsp[(3) - (3)].t));
        (yyval.varsy) = new VaSymbol((yyvsp[(1) - (3)].str), vv);
    }
    break;

  case 191:
#line 1996 "readnet-syntax.yy"
    { (yyval.form) = NULL; }
    break;

  case 192:
#line 1997 "readnet-syntax.yy"
    { (yyval.form) = (yyvsp[(1) - (1)].form); }
    break;

  case 193:
#line 2002 "readnet-syntax.yy"
    {
        (yyvsp[(2) - (4)].varsy)->name[0] = '\0';
        (yyval.form) = new quantifiedformula(qe,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
    }
    break;

  case 194:
#line 2006 "readnet-syntax.yy"
    {
        (yyvsp[(2) - (4)].varsy)->name[0] = '\0';
        (yyval.form) = new quantifiedformula(qa,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
    }
    break;

  case 195:
#line 2010 "readnet-syntax.yy"
    {
        (yyval.form) = new binarybooleanformula(conj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
    }
    break;

  case 196:
#line 2013 "readnet-syntax.yy"
    {
        (yyval.form) = new binarybooleanformula(disj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
    }
    break;

  case 197:
#line 2016 "readnet-syntax.yy"
    {
        (yyval.form) = new unarybooleanformula(neg,(yyvsp[(2) - (2)].form));
    }
    break;

  case 198:
#line 2019 "readnet-syntax.yy"
    { (yyval.form) = (yyvsp[(2) - (3)].form); }
    break;

  case 199:
#line 2020 "readnet-syntax.yy"
    {
#if defined(STATESPACE) && defined(STUBBORN)
        (yyvsp[(1) - (1)].ts)->transition->visible = true;
        //                    std::cerr << "visible transition: " << $1->name << "n";
#endif
        if ((yyvsp[(1) - (1)].ts)->vars && (yyvsp[(1) - (1)].ts)->vars->card) {
            yyerrors((yyvsp[(1) - (1)].ts)->name, "high-level transition '%s' requires firing mode", _cimportant_((yyvsp[(1) - (1)].ts)->name));
        }
        (yyval.form) = new transitionformula((yyvsp[(1) - (1)].ts)->transition);
    }
    break;

  case 200:
#line 2030 "readnet-syntax.yy"
    {
#if defined(STATESPACE) && defined(STUBBORN)
        (yyvsp[(1) - (5)].ts)->transition->visible = true;
        //                    std::cerr << "visible transition: " << $1->name << "n";
#endif
        if ((! (yyvsp[(1) - (5)].ts)->vars) || ((yyvsp[(1) - (5)].ts)->vars->card == 0)) {
            yyerrors((yyvsp[(1) - (5)].ts)->name, "low-level transition '%s' does not require firing mode", _cimportant_((yyvsp[(1) - (5)].ts)->name));
        }
        (yyval.form) = new transitionformula((yyvsp[(1) - (5)].ts), (yyvsp[(4) - (5)].fm));
    }
    break;

  case 201:
#line 2044 "readnet-syntax.yy"
    {
        TS = (TrSymbol*) TransitionTable->lookup((yyvsp[(1) - (1)].str));
        if (!TS) {
            yyerrors((yyvsp[(1) - (1)].str), "transition '%s' does not exist", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        (yyval.ts) = TS;
    }
    break;

  case 202:
#line 2055 "readnet-syntax.yy"
    { (yyval.fm) = (yyvsp[(1) - (1)].fm); }
    break;

  case 203:
#line 2056 "readnet-syntax.yy"
    { (yyvsp[(1) - (3)].fm)->next = (yyvsp[(3) - (3)].fm); (yyval.fm) = (yyvsp[(1) - (3)].fm); }
    break;

  case 204:
#line 2061 "readnet-syntax.yy"
    {
        VS = (VaSymbol*)(TS->vars->lookup((yyvsp[(1) - (3)].str)));
        if (!VS) {
            yyerrors((yyvsp[(1) - (3)].str), "no such transition variable '%s'", _cimportant_((yyvsp[(1) - (3)].str)));
        }
        if (!(VS->var->type->iscompatible((yyvsp[(3) - (3)].ex)->type))) {
            yyerror("variable binding incompatible with variable type");
        }
        (yyval.fm) = new fmode(VS, (yyvsp[(3) - (3)].ex), NULL);
    }
    break;

  case 205:
#line 2075 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
        BuchiTable = new SymbolTab(10);
    }
    break;

  case 206:
#line 2078 "readnet-syntax.yy"
    {
        {
            int j;
            buchitransition* bt;
            for (int i = 0; i < buchistate::nr; i++) {
                buchistate* b = buchiautomaton[i];
                b->delta = new buchitransition * [b->nrdelta + 1];
                for (j = 0, bt = b->transitionlist; bt; bt = bt->next, j++) {
                    b->delta[j] = bt;
                }
            }
        }
        // process all guard formulas
        for (unsigned int i = 0; i < Globals::Places[0]->NrSignificant; i++) {
            Globals::Places[i]->cardprop = 0;
            Globals::Places[i]->propositions = NULL;
        }
        for (int i = 0; i < buchistate::nr; i++)
            for (int j = 0; j < buchiautomaton[i]->nrdelta; j++) {
                int res;
                buchiautomaton[i]->delta[j]->guard = buchiautomaton[i]->delta[j]->guard->replacequantifiers();
                buchiautomaton[i]->delta[j]->guard->tempcard = 0;
                buchiautomaton[i]->delta[j]->guard = buchiautomaton[i]->delta[j]->guard->merge();
                buchiautomaton[i]->delta[j]->guard = buchiautomaton[i]->delta[j]->guard->reduce(&res);
                if (res == 0) {
                    buchiautomaton[i]->delta[j] = NULL;
                }
                buchiautomaton[i]->delta[j]->guard = buchiautomaton[i]->delta[j]->guard->posate();
                buchiautomaton[i]->delta[j]->guard->tempcard = 0;
            }
        for (int i = 0; i < buchistate::nr; i++)
            for (int j = 0; j < buchiautomaton[i]->nrdelta; j++) {
                buchiautomaton[i]->delta[j]->guard->setstatic();
                if (buchiautomaton[i]->delta[j]->guard->tempcard) {
                    yyerror("temporal operators not allowed in Buchi automaton");
                }
            }

#endif
    }
    break;

  case 207:
#line 2122 "readnet-syntax.yy"
    {
        buchiautomaton = new buchistate* [buchistate::nr];
        for (buchistate* b = initialbuchistate; b; b = b->next) {
            buchiautomaton[b->code] = b;
        }
    }
    break;

  case 208:
#line 2132 "readnet-syntax.yy"
    {
        StSymbol* s ;
        if ((s = (StSymbol*)(BuchiTable->lookup((yyvsp[(3) - (3)].str))))) {
            yyerrors((yyvsp[(3) - (3)].str), "state name '%s' in Buchi automaton used twice", _cimportant_((yyvsp[(3) - (3)].str)));
        }
        s = new StSymbol((yyvsp[(3) - (3)].str));
        if (!initialbuchistate) {
            initialbuchistate = s->state;
        } else {
            s->state->next = initialbuchistate->next;
            initialbuchistate->next = s->state;
        }
    }
    break;

  case 209:
#line 2145 "readnet-syntax.yy"
    {
        StSymbol* s;
        if ((s = (StSymbol*)(BuchiTable->lookup((yyvsp[(1) - (1)].str))))) {
            yyerrors((yyvsp[(1) - (1)].str), "state name '%s' in Buchi automaton used twice", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        s = new StSymbol((yyvsp[(1) - (1)].str));
        if (!initialbuchistate) {
            initialbuchistate = s->state;
        } else {
            s->state->next = initialbuchistate->next;
            initialbuchistate->next = s->state;
        }
    }
    break;

  case 211:
#line 2167 "readnet-syntax.yy"
    {
        StSymbol* s = (StSymbol*) BuchiTable->lookup((yyvsp[(3) - (3)].str));
        if (!s) {
            yyerrors((yyvsp[(3) - (3)].str), "state '%s' does not exist", _cimportant_((yyvsp[(3) - (3)].str)));
        }
        s->state->final = 1;
    }
    break;

  case 212:
#line 2174 "readnet-syntax.yy"
    {
        StSymbol* s = (StSymbol*) BuchiTable->lookup((yyvsp[(1) - (1)].str));
        if (!s) {
            yyerrors((yyvsp[(1) - (1)].str), "state '%s' does not exist", _cimportant_((yyvsp[(1) - (1)].str)));
        }
        s->state->final = 1;
    }
    break;

  case 215:
#line 2191 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(2); }
    break;

  case 216:
#line 2191 "readnet-syntax.yy"
    {
        StSymbol* from = (StSymbol*) BuchiTable->lookup((yyvsp[(2) - (7)].str));
        if (!from) {
            yyerrors((yyvsp[(2) - (7)].str), "state '%s' does not exist", _cimportant_((yyvsp[(2) - (7)].str)));
        }
        StSymbol* to = (StSymbol*) BuchiTable->lookup((yyvsp[(4) - (7)].str));
        if (!to) {
            yyerrors((yyvsp[(4) - (7)].str), "state '%s' does not exist", _cimportant_((yyvsp[(4) - (7)].str)));
        }
        buchitransition* bt = new buchitransition;
        bt->next = from->state->transitionlist;
        from->state->transitionlist = bt;
        (from->state->nrdelta)++;
        bt->delta = to->state;
        bt->guard = (yyvsp[(7) - (7)].form);
    }
    break;


/* Line 1267 of yacc.c.  */
#line 4266 "readnet-syntax.cc"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 2210 "readnet-syntax.yy"


char* diagnosefilename = NULL;


void readnet() {
//    yydebug = 0;

    if (Globals::netfile) {
        yyin = fopen(Globals::netfile, "r");
        if (!yyin) {
            abort(4, "cannot open net file '%s'", _cfilename_(Globals::netfile));
        }
        status("reading net from file '%s'", _cfilename_(Globals::netfile));
        diagnosefilename = Globals::netfile;
    } else {
        status("reading net from standard input");
    }

    GlobalTable = new SymbolTab(1024);
    TheBooType = new UBooType();
    TheNumType = new UNumType(0, INT_MAX);

    yyparse();

	#ifdef BOUNDEDPLACE
        if (!Globals::CheckPlace) {
			abort(4, "place to be checked is missing (see analysis task file)");
        }
	#endif
	#ifdef DEADTRANSITION
		    if (!Globals::CheckTransition) {
		        abort(4, "transition to be checked is missing (see analysis task file)");
		    }
	#endif
	#ifdef STATEPREDICATE
		if (!F) {
			abort(4, "predicate to be checked is missing (see analysis task file)");
		}
	#endif

    // get initial marking
    for (unsigned int ii = 0; ii < Globals::Places[0]->cnt; ii++) {
        Globals::CurrentMarking[ii] = Globals::Places[ii]->initial_marking;
        Globals::Places[ii]->index = ii;
    }

    if (F) {
        F = F->replacequantifiers();
        F->tempcard = 0;
        F = F->merge();
#if defined(MODELCHECKING)
        unsigned int i;
        for (i = 0; i < Globals::Transitions[0]->cnt; i++) {
            Globals::Transitions[i]->lstfired = new unsigned int [F->tempcard];
            Globals::Transitions[i]->lstdisabled = new unsigned int [F->tempcard];
        }
#endif
    }
}


/// display a parser error and exit
void yyerrors(char* token, char const* format, ...) {
    fprintf(stderr, "%s: %s:%d:%d - ", _ctool_(PACKAGE),
    _cfilename_(basename(diagnosefilename)), yylineno, yycolno);

    va_list args;
    va_start(args, format);
    vfprintf(stderr, format, args);
    va_end(args);

    fprintf(stderr, "\n");
    message("error near '%s'", token);
    displayFileError(diagnosefilename, yylineno, token);
    abort(3, "syntax error");
}


/// display a parser error and exit
void yyerror(char const* mess) {
    yyerrors(yytext, mess);
}

