#include "Place.h"

unsigned int Place::hash_value = 0;
