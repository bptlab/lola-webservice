// See the manual for a description and all possible parameters.

// NUMERICAL PARAMETERS
#define REPORTFREQUENCY 100000
#define HASHSIZE 65536

// REDUCTION TECHNIQUES
#define PREDUCTION
//#define STUBBORN

// GRAPH EXPLORATION STRATEGY
#define BREADTH_FIRST

// VERIFICATION PROBLEM
#define STATESPACE

#define LIMITCAPACITY

