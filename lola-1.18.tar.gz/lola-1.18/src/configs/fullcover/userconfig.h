// See the manual for a description and all possible parameters.

// NUMERICAL PARAMETERS
#define REPORTFREQUENCY 100000
#define HASHSIZE 65536

// REDUCTION TECHNIQUES
#define COVER
#define PREDUCTION

// GRAPH EXPLORATION STRATEGY
#define DEPTH_FIRST

// VERIFICATION PROBLEM
#define FULL
